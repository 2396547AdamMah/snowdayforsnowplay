/// @description Insert description here
// You can write your code in this editor
image_blend = isBackground ? #A1A3BE: ctrlGame.roomColor;


//draw_line(x,y,x+dir*wallAvoidRange,y);
event_inherited();