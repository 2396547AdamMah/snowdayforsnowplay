/// @description Insert description here
// You can write your code in this editor
image_xscale = dir;

flapTimer++;

if (flapTimer >= timeForNextFlap) {
	hspd = flapSpeed * dir;
	image_index = 0;
	image_speed = 1;
	flapTimer = 0;
	timeForNextFlap = irandom_range(flapDelayMin,flapDelayMax);
}
hspd = lerp(hspd,glideSpeedMin*dir,glideDecel);

if (collision_line(x,y,x+dir*wallAvoidRange,y,tilemap,true,false) != noone) {
	dir = -dir;
	flapTimer = timeForNextFlap;
}
var _dist = abs(x - xstart);
if (_dist >= maxRangeH && flapTimer < timeForNextFlap) {
	dir = -dir;
	x += dir * 4;
	flapTimer = timeForNextFlap;
}

// Inherit the parent event
event_inherited();

//x = round(x);
//y = round(y);
if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}

