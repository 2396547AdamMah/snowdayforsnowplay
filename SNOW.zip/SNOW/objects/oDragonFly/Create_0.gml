/// @description Insert description here
// You can write your code in this editor

event_inherited();

dir = image_xscale;
flapTimer = 0;

flapDelayMin = 120;
flapDelayMax = 340;
flapSpeed = 1.5;

timeForNextFlap = irandom_range(flapDelayMin,flapDelayMax);

wallAvoidRange = 48;
maxRangeH = 190;


glideDecel = 0.01;
glideSpeedMin = 0.2;

image_speed = 0;

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})
