/// @description Insert description here
// You can write your code in this editor

switch (state) {
	
	
	case "IDLE": 
		image_speed = 1;
		sprite_index = sFox_Idle;
		if (collision_circle(x,y,playerDetectRange,oPlayer,false,false) != noone) {
			state = "WALK";
			var _dist = abs(x - oPlayer.x);
			jumpTimer = _dist < 48 ? irandom_range(jumpDelayMin,jumpDelayMax): 30
		}
		break;
	
	case "WALK":
		image_speed = 1;
		jumpTimer--;
		sprite_index = sFox_Walk;
		var _dist = abs(oPlayer.x - x);
		var _dir = sign(oPlayer.x - x);
		image_xscale = _dir != 0 ? _dir : image_xscale;
		
		hspd = lerp(hspd,walkSpd * _dir,0.1);
		
		if (jumpTimer <= 0) {
			state = "PRONE";
			jumpDir = _dir;
			proneTimer = 0;
			
		}
		
		break;
	
	case "PRONE": {
		image_speed = 0;
		sprite_index = sFox_Prone;

		proneTimer++;
		
		if (proneTimer > proneDelay) {
			hspd = irandom_range(jumpSpeedMin,jumpSpeedMax) * jumpDir;
			vspd = -jumpHeight;
			state = "JUMP";
		}
	} break;
	
	case "JUMP":
		image_speed = 0;
		sprite_index = sFox_Walk;
		image_index = 2;
		
		if (onGround()) {
			state = "WALK"; 
			hspd *= 0.9;
			var _dist = abs(x - oPlayer.x);
			jumpTimer = _dist < 96 ? irandom_range(jumpDelayMin,jumpDelayMax): 5
		}
		break;
}

vspd += 0.15;

event_inherited();

if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}