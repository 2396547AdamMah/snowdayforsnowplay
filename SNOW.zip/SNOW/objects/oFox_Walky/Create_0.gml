/// @description Insert description here
// You can write your code in this editor
event_inherited();

state = "IDLE";

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})

playerDetectRange = 80;
walkSpd = 0.8;

jumpDelayMin = 90;
jumpDelayMax = 110;

jumpTimer = 0;

jumpSpeed = 4.5;
jumpHeight = 2;
jumpSpeedMin = 3.8;
jumpSpeedMax = 4.8;

proneTimer = 0;
proneDelay = 24;

runSpeed = 4;
jumpDir = 0;