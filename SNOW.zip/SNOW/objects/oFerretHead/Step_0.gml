/// @description Insert description here
// You can write your code in this editor

//show_debug_message(tilemap_get_at_pixel(tilemap,mouse_x,mouse_y))

switch (state) {
	case "CRAWL":
		if (target != noone) {
			//var _dir = sign(oPlayer.x - x);
		
			
		
			//var _vert = sign(oPlayer.y - y);
			
			//var _poleV = instance_place(x,y,oClimbablePole);
			var _poleV = instance_nearest(x,y,oClimbablePole);
			var _dist = point_distance(x,y,_poleV.x,_poleV.y);
			//show_debug_message(_dist);
			var _dir = sign(_poleV.x - x);
			if (instance_exists(_poleV)) {
				_poleV.image_alpha = 0.5;
				_poleV.image_blend = c_green;
			}
			//show_debug_message(vertWanted)
			if (_poleV != noone && _dist < 96) {
				var _polePlayerDist = point_distance(_poleV.x,_poleV.y,target.x, target.y);
				if (vertWanted < 0 && y > target.y + 40 ) {
					hspd = lerp(hspd, moveSpeed * _dir,moveAccel);
					if (place_meeting(x,y,_poleV) ) {
						state = "CLIMB_POLE";
						climbingOn = _poleV;
						hspd = 0;
						x = _poleV.x;
					}
				} else if (vertWanted > 0 && y < target.y - 40) {
					hspd = lerp(hspd, moveSpeed * _dir,moveAccel);
					if (place_meeting(x,y,_poleV) ) {
						state = "CLIMB_POLE";
						climbingOn = _poleV;
						hspd = 0;
						x = _poleV.x;
					}
				} else {
					hspd = lerp(hspd,moveSpeed * sign(horiWanted),moveAccel);
				}
				
				
			} else {
				hspd = lerp(hspd,moveSpeed * sign(horiWanted),moveAccel);
			}
			
			//var _yDiff = vertWanted;
			//show_debug_message(_yDiff);
			//if (_yDiff < -8) {
				//image_blend = c_red;
				//
			//} else if (_yDiff > 8) {
				//image_blend = c_green;
			//} else image_blend = c_white;
			
			
			//var _poleH = instance_place(x,y,oClimbable);
			
		}
		vspd += grav;
		
		
		break;
	case "CLIMB_POLE":
		//var _dir = sign(oPlayer.y - y);
		
		//vspd = lerp(vspd,climbSpeed * _dir,moveAccel);
		y = clamp(y,climbingOn.bbox_top,climbingOn.bbox_bottom);
		
		var _poleH = instance_nearest(x,y,oClimbable);
		var _dist = point_distance(x,y,_poleH.x,_poleH.y);
		var _dir = sign(_poleH.x - x);
		var _heightCondition = true;
		if (instance_exists(_poleH)) {
			_poleH.image_alpha = 0.5;
			_poleH.image_blend = c_green;
		}
		
		//if (climbingOn != noone) {
			//if (vertWanted < 0) {
				//_heightCondition = (_poleH.y < climbingOn.bbox_bottom)
			//} else if (vertWanted > 0) {
				//_heightCondition = (_poleH.y > climbingOn.bbox_top)
			//}
		//}
		
		if (target.onGround() && onGround()) {
			state = "CRAWL";
			climbingOn = noone;
		}
		if (_poleH != noone && _dist < poleDetectDistance ) {
			if (vertWanted < 0) {
				if (_poleH.y <= oPlayer.y || climbingOn.bbox_top > oPlayer.y) {
					var _poleDir = sign(_poleH.y - y); 
					vspd = lerp(vspd,climbSpeed * _poleDir,moveAccel);
					
					if (place_meeting(x,y,_poleH)) {
						state = "CLIMB_HANG";
						vspd = 0;
						y = _poleH.y+2;
						climbingOn = _poleH;
					}
				} else {
					vspd = lerp(vspd,climbSpeed * sign(vertWanted),moveAccel);
				}
			} else if (vertWanted > 0) {
				if (_poleH.y >= oPlayer.y || climbingOn.bbox_bottom < oPlayer.y) {
					var _poleDir = sign(_poleH.y - y); 
					vspd = lerp(vspd,climbSpeed * _poleDir,moveAccel);
					
					if (place_meeting(x,y,_poleH)) {
						state = "CLIMB_HANG";
						vspd = 0;
						y = _poleH.y+2;
						climbingOn = _poleH;
					}
				} else {
					vspd = lerp(vspd,climbSpeed * sign(vertWanted),moveAccel);
				}
			}
			//else 
			//if (horiWanted > 0 && oPlayer.x > x) {
				//var _poleDir = sign(_poleH.y - y); 
				//vspd = lerp(vspd,climbSpeed * _poleDir,moveAccel);
				//
				//if (place_meeting(x,y,_poleH)) {
					//state = "CLIMB_HANG";
					//vspd = 0;
					//y = _poleH.y+2;
					//climbingOn = _poleH;
				//}
			//}
			//else if (horiWanted < 0 && oPlayer.x < x) {
				//var _poleDir = sign(_poleH.y - y); 
				//vspd = lerp(vspd,climbSpeed * _poleDir,moveAccel);
				//
				//if (place_meeting(x,y,_poleH)) {
					//state = "CLIMB_HANG";
					//vspd = 0;
					//y = _poleH.y+2;
					//climbingOn = _poleH;
				//}
			//}
		 	else {
				vspd = lerp(vspd,climbSpeed * sign(vertWanted),moveAccel);
			}
			//var _poleDir = sign(_poleH.y - y); 
			//vspd = lerp(vspd,climbSpeed * _poleDir,moveAccel);
			//
			//if (place_meeting(x,y,_poleH)) {
				//state = "CLIMB_HANG";
				//vspd = 0;
				//y = _poleH.y+2;
				//climbingOn = _poleH;
			//}
			
		} else {
			vspd = lerp(vspd,climbSpeed * sign(vertWanted),moveAccel);
		}
		
		//var _hori = sign(oPlayer.x - x);
		//var _poleH = instance_place(x,y,oClimbable);
		//
		//if (place_meeting(x,y+4,tilemap) && target.onGround() && abs(oPlayer.x - x) > 4) {
			//state = "CRAWL";
			//climbingOn = noone;
		//}
		//
		//if (climbingOn != noone) {
			//if (vertWanted < 0) {
				//if (_poleH != noone && _hori != 0 && climbingOn.y > _poleH.y) {
					//y=_poleH.y+2;
					//state = "CLIMB_HANG";
					//climbingOn = _poleH;
					//vspd = 0;
				//}
			//} else {
				//if (_poleH != noone && _hori != 0 && climbingOn.y -16 < _poleH.y) {
					//y=_poleH.y+2;
					//state = "CLIMB_HANG";
					//climbingOn = _poleH;
					//vspd = 0;
				//}
			//}
			//
			////if (_poleH != noone && _hori != 0 && vertWanted > 0 && climbingOn.y < y + vertWanted*8) {
				////y=_poleH.y+2;
				////state = "CLIMB_HANG";
				////climbingOn = _poleH;
				////vspd = 0;
			////}
		//} else {
			//if (_poleH != noone && _hori != 0) {
				//y=_poleH.y+2;
				//state = "CLIMB_HANG";
				//climbingOn = _poleH;
				//vspd = 0;
			//}
		//}
			
		
		break;
	
	case "CLIMB_HANG":
		//var _dir = sign(oPlayer.x - x);
		
		//hspd = lerp(hspd, climbSpeed * sign(horiWanted), moveAccel);
		x = clamp(x,climbingOn.bbox_left,climbingOn.bbox_right);
		
		
		var _poleV = instance_nearest(x,y,oClimbablePole);
		var _dist = point_distance(x,y,_poleV.x,_poleV.y);
		var _dir = sign(_poleV.x - x);
		var _heightCondition = true;
		if (instance_exists(_poleV)) {
			_poleV.image_alpha = 0.5;
			_poleV.image_blend = c_green;
		}
		//if (climbingOn != noone) {
			//
			//if (vertWanted < 0) {
				//_heightCondition = (_poleV.bbox_top < climbingOn.y);
			//} else if (vertWanted > 0) {
				//_heightCondition = (_poleV.bbox_bottom > climbingOn.y)
			//}
		//}
		
		if (_poleV != noone && _dist < 64) {
			if (vertWanted < 0 && oPlayer.y + 6 < y) {
				hspd = lerp(hspd, climbSpeed * _dir,moveAccel);
				if (place_meeting(x,y,_poleV)) {
					state = "CLIMB_POLE";
					climbingOn = _poleV;
					hspd = 0;
					x = _poleV.x;
				}
			} else if (vertWanted > 0 && oPlayer.y - 6 > y) {
				hspd = lerp(hspd, climbSpeed * _dir,moveAccel);
				if (place_meeting(x,y,_poleV)) {
					state = "CLIMB_POLE";
					climbingOn = _poleV;
					hspd = 0;
					x = _poleV.x;
				}
			} else {
				hspd = lerp(hspd,climbSpeed * sign(horiWanted),moveAccel);
			}
			
			
		} else {
			hspd = lerp(hspd,climbSpeed * sign(horiWanted),moveAccel);
		}
		//if (vertWanted > 0 && _poleV != noone && _poleV.y > y) {
			//state = "CLIMB_POLE";
			//climbingOn = _poleV;
			//hspd = 0;
		//} else if (_vert < 0 && _poleV != noone && _poleV.y < y) {
			//state = "CLIMB_POLE";
			//climbingOn = _poleV;
			//hspd = 0;
		//}
		//
		break;
}
if (climbingOn != noone) {
	climbingOn.image_alpha = 0.5;
	climbingOn.image_blend = c_red;
}
//if (Input.kLeft) {
	//hspd = -2;
//} else if (Input.kRight) {
	//hspd = 2;
//} else hspd = 0;
//x = mouse_x;
//y = mouse_y;

// Inherit the parent event
event_inherited();

