/// @description Insert description here
// You can write your code in this editor
event_inherited();
function findClosestClimbable() {
	var _list =ds_list_create();
	var _climbables = collision_circle_list(x,y,240,oClimbablePole,false,true,_list,false);
	
	if (ds_list_size(_list) <= 0) {
		return -1;
	}
	var _closest = ds_list_find_value(_list,0);
	for (var i = 0; i < ds_list_size(_list); i++) {
		var _elem = ds_list_find_value(_list, i);
		var _distX = abs(x - _elem.x);
		var _distY = abs(y - _elem.y);
		
		if (_distX <= abs(x - _closest.x) 
			&& _distY <= abs(y - _closest.y)) {
			_closest = _elem;
		}
	}
	
	return _closest;

}
function findClimbablePath(_target = oPlayer) {
	var _dir = point_direction(x,y,_target.x,_target.y);
	var _dist = point_distance(x,y,_target.x,_target.y);
	var _final = [];
	if (climbingOn == noone) {
		var _closest = findClosestClimbable();
		if (_closest != -1) {
			_final = _closest.poleTouchingTreePlayer();
		}
	} else {
		_final = climbingOn.poleTouchingTreePlayer();
	}
	
	return _final;
	
	
}
numberParts = 6;
partScale = [1.3,1.3,1.15,1,0.9,0.8]
var _previous = id;
for (var i = 0; i < numberParts; i++) {
	var _scale = partScale[i]
	var _next = instance_create_depth(x,y + i*6,depth+i,oFerretBody, {
		previous: _previous,
		head: id,
		image_xscale: _scale,
		image_yscale: _scale
	});
	_previous = _next;
}

state = "CRAWL";
target = oPlayer;
grav = 0.15
moveSpeed = 1.8;
moveAccel = 0.2;
climbingOn = noone;

climbSpeed = 1.6;


horiWanted = 0;
vertWanted = 0;
ferretPath = path_add();
setup = false;

poleDetectDistance = 64;
climbables = []
climbablesIndex = 0;
alarm[0] = 1;