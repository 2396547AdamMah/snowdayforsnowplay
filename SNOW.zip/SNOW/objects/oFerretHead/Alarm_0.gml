/// @description Insert description here
// You can write your code in this editor
//if (!setup) {
	//
	//if (variable_global_exists("pathfindingGrid")) {
		//setup = true;
	//}
	//alarm[0] = 1;
	//exit;
//}

if (oPlayer.climbingOn != noone) {
	var _climbables = findClimbablePath(oPlayer);
	climbablesIndex = 0;
	
	//if (_climbables != climbables) {
		//climbables = _climbables;
		//climbablesIndex = 0;
	//}
	//show_debug_message(climbables);
} else {
	//climbables = [];
}
alarm[0] = 30;


path_delete(ferretPath);
ferretPath = path_add();

//mp_grid_path(global.pathfindingGrid,ferretPath,x,y,target.x,target.y,true);
//var _x = path_get_point_x(ferretPath,path_get_number(ferretPath)-1); 
//var _y = path_get_point_y(ferretPath,path_get_number(ferretPath)-1); 
horiWanted = (oPlayer.x - x);
vertWanted = (oPlayer.y - y);





alarm[0] = 10