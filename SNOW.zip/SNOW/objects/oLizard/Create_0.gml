/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

moveSpeed = 1.25;
wallSpeed = 0.9;

dir = 1;
state = "FLOOR_WALK";

wallClinging = 0;
grav = 0.15;

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})