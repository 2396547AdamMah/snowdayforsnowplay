/// @description Insert description here
// You can write your code in this editor


switch (state) {
	case "FLOOR_WALK":
		sprite_index = sLizard_Walk;
		var _dir = sign(oPlayer.x - x);
		if (_dir != 0) dir = _dir;
			
		if (hspd != 0) image_xscale = sign(hspd);
		
		hspd = lerp(hspd, moveSpeed * dir,0.2);
		vspd += grav;
		
		//if (collision_circle(x,y,80,oPlayer,false,false) != noone 
			//&& oPlayer.y - y < -10
			//&& onGround()) {
			//state = "WALL_JUMP";
			////x += -wallClinging * 8
			//hspd = 2 * _dir;
			//vspd = -2;
			////image_angle = 0;
			////image_xscale = -wallClinging;
			////image_yscale = 1;
			////wallClinging = 0;
		//}
		//if (place_meeting(x+1,y,tilemap) && dir > 0) {
			//image_angle = 90;
			//hspd = 0;
			//state = "WALL_WALK";
			//image_xscale = 1;
			//image_yscale = 1;
			//if (!place_meeting(x,y-1,tilemap)) {
				//y -= 6;
			//}
		//}
		if (wallClinging != 0) {
			state = "WALL_WALK";
			image_angle = 90;
			image_xscale = 1;
			image_yscale = wallClinging;
			y -= 8;
			x += 7 * wallClinging;
			hspd = 0;
		}
		break;
	case "WALL_WALK": {
		sprite_index = sLizard_Walk;
		vspd = lerp(vspd,-wallSpeed,0.2);
		image_yscale = wallClinging;
		
		if (!place_meeting(x+wallClinging,y,tilemap)) {
			state = "FLOOR_WALK";
			vspd = 0;
			image_angle = 0;
			image_xscale = wallClinging;
			image_yscale = 1;
			wallClinging = 0;
		}
		
		var _dir = sign(oPlayer.x - x);
		var _vert = sign(oPlayer.y - y);
		if (wallClinging < 0 && _dir > 0 && _vert > 0) {
			state = "WALL_JUMP";
			x += -wallClinging * 8
			hspd = 2 * -wallClinging;
			vspd = -1;
			image_angle = 0;
			image_xscale = -wallClinging;
			image_yscale = 1;
			wallClinging = 0;
		} 
		if (wallClinging > 0 && _dir < 0 && _vert > 0) {
			state = "WALL_JUMP";
			x += -wallClinging * 8
			hspd = 2 * -wallClinging;
			vspd = -1;
			image_angle = 0;
			image_xscale = -wallClinging;
			image_yscale = 1;
			wallClinging = 0;
		} 
		//if (_dir != wallClinging && _vert > 0) {
			//
		//}
	} break;
		
	case "WALL_JUMP": {
		sprite_index = sLizard_Idle;
		vspd += grav;
		if (wallClinging != 0) {
			state = "WALL_WALK"
			image_angle = 90;
			image_xscale = 1;
			image_yscale = wallClinging;
			y -= 8;
			x += 7 * wallClinging;
			hspd = 0;
		}
		if (onGround()) {
			state = "FLOOR_WALK";
		}
	} break;
}

// Inherit the parent event
//event_inherited();

if state == "FLOOR_WALK" {
	if place_meeting(x+hspd,y,tilemap) {
		yplus = 0;
		while (place_meeting(x+hspd,y-yplus,tilemap) && yplus <= abs(1*hspd)) {
			yplus += 1;
		}
		if place_meeting(x+hspd,y-yplus,tilemap)
		{
			while (!place_meeting(x+sign(hspd),y,tilemap)) {
				x+=sign(hspd);
				//glowObj.x += sign(hspd)
			}
			if (hspd > 0) {
				wallClinging = 1;
			} else if (hspd < 0) {
				wallClinging = -1;
			} else wallClinging = 0;
			
			hspd = 0;
			
			
		}
		else
		{
			y -= yplus;
		}
	}
} else collisionsX();
	
x += hspd;

collisionsY();

y += vspd;

if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}