/// @description Insert description here
// You can write your code in this editor
if (!freeRoamMode) {
	freeRoamMode = true;
	oPlayer.state = ePlayerState.NOCLIP;
	oCam.noclip = true;
} 
else {
	freeRoamMode = false;
	oPlayer.state = ePlayerState.FREE;
	oCam.noclip = false;
}
