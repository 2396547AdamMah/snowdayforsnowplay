/// @description Insert description here
// You can write your code in this editor
currentRoom = rmStart;
global.gamePaused = false;


//False animal habitats kept running after sapient extinction
//one habitat super infected, lie metroids or the rot
//dark place rails between habitats

enum ePartType  {
	SNOW_SLOW,
	SNOW_WINDY,
	RAIN
}

enum eFlags {
	HAS_GLIDE,
	LENGTH //ALWAYS LAST ELEM
}



flags = array_create(eFlags.LENGTH,false);
flags[eFlags.HAS_GLIDE] = false;

freeRoamMode = false;
carrots = 0;
inputManager = new InputManager();
noSpidersMode = false;
//grid = instance_create_depth(x,y,depth,oGrid);
//snowWindDir = 195;

nextRoom = rmOutside_1;
nextX = 0;
nextY = y;
elev = noone;

function saveGame() {
	
}

function gotoRoom (_room, _x, _y, _dir,_elev) {
	instance_create_depth(0,0,-9999,oFadeout,{owner: id})
	nextRoom = _room;
	nextX = x;
	nextY = y;
	elev = _elev;
	
	//
	//oPlayer.x = _x;
	//oPlayer.y = _y;
	//oPlayer.state = ePlayerState.FREE;
	//var _elev = instance_create_depth(_x-16,y+8,oPlayer.depth,oElevator);
	//_elev.dir = 90;
	//_elev.rider = oPlayer;
	//_elev.elevating = true;
	//_elev.timer = 0;	
}

function onFadeoutMiddle(_fade) {
	show_debug_message(nextRoom);
	room_goto(nextRoom);
	currentRoom = nextRoom;
	if (instance_exists(elev)) {
		elev.x = nextX;
		elev.y = nextY;
	} else {
		oPlayer.x = nextX;
		oPlayer.y = nextY;
	}
	_fade.fadeOut = 1;
}

#macro Input ctrlGame.inputManager 

color_old1 = shader_get_uniform(shd_colorReplace,"color_old1");
color_new1 = shader_get_uniform(shd_colorReplace,"color_new1");

color_old2 = shader_get_uniform(shd_colorReplace,"color_old2");
color_new2 = shader_get_uniform(shd_colorReplace,"color_new2");

color_old3 = shader_get_uniform(shd_colorReplace,"color_old3");
color_new3 = shader_get_uniform(shd_colorReplace,"color_new3");

color_old4 = shader_get_uniform(shd_colorReplace,"color_old4");
color_new4 = shader_get_uniform(shd_colorReplace,"color_new4");

color_old5 = shader_get_uniform(shd_colorReplace,"color_old5");
color_new5 = shader_get_uniform(shd_colorReplace,"color_new5");

roomColor = c_fuchsia;
backColor = c_aqua;