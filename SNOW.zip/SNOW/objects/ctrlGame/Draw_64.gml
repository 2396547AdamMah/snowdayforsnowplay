/// @description Insert description here
// You can write your code in this editor
if (freeRoamMode) {
	draw_text(16,32,$"Carrots : {carrots}")
}
