/// @description Insert description here
// You can write your code in this editor
gotoRoom(currentRoom,oPlayer.xstart,oPlayer.ystart,0,noone)