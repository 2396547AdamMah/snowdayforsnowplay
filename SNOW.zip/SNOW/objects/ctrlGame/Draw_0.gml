/// @description Insert description here
// You can write your code in this editor


////125663
//shader_set_uniform_f(color_old1,0x3d/255,0x33/255,0x6c/255,1/255);
//shader_set_uniform_f(color_new1,0x3d/255,0x33/255,0x6c/255);
////261E4C
////459E92
//shader_set_uniform_f(color_old2,0x26/255,0x1e/255,0x4c/255,1/255);
//shader_set_uniform_f(color_new2,0x26/255,0x1e/255,0x4c/255);
////19163E
////7ACCBE
//
//shader_set_uniform_f(color_old3,0x19/255,0x16/255,0x3e/255,1/255);
//shader_set_uniform_f(color_new3,0x19/255,0x16/255,0x3e/255);
////0F0F33
////44E5CA
//shader_set_uniform_f(color_old4,0x0f/255,0x0f/255,0x33/255,1/255);
//shader_set_uniform_f(color_new4,0x0f/255,0x0f/255,0x33/255);
//
////e5efff
//shader_set_uniform_f(color_old5,0xe5/255,0xef/255,0xff/255,1/255);
//shader_set_uniform_f(color_new5,0xe5/255,0xef/255,0xff/255);
//

//shader_set_uniform_f(color_old1,0x3d/255,0x33/255,0x6c/255,1/255);
//shader_set_uniform_f(color_new1,0x12/255,0x56/255,0x63/255);
////261E4C
////459E92
//shader_set_uniform_f(color_old2,0x26/255,0x1e/255,0x4c/255,1/255);
//shader_set_uniform_f(color_new2,0x45/255,0x9e/255,0x92/255);
////19163E
////7ACCBE
//
//shader_set_uniform_f(color_old3,0x19/255,0x16/255,0x3e/255,1/255);
//shader_set_uniform_f(color_new3,0x7a/255,0xcc/255,0xbe/255);
////0F0F33
////44E5CA
//shader_set_uniform_f(color_old4,0x0f/255,0x0f/255,0x33/255,1/255);
//shader_set_uniform_f(color_new4,0x44/255,0xe5/255,0xca/255);
//
////e5efff
//shader_set_uniform_f(color_old5,0xe5/255,0xef/255,0xff/255,1/255);
//shader_set_uniform_f(color_new5,0xe5/255,0xef/255,0xff/255);
//

//shader_set(shd_colorReplace);

draw_self();