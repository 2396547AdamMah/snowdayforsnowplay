/// @description Insert description here
// You can write your code in this editor
if (room != rmStart) {
	grid = instance_create_depth(x,y,depth,oGrid);
}


if (room == rmOutside || room == rmOutside_1) {
	roomColor = #595D7F;
	backColor = #C5CAE2
} else if (room == rmDarkSnow) {
	roomColor = #3D336C;
	backColor = #0F0F33;
} else if (room == rmDarkest) {
	roomColor = #1D213D
} else if (room == rmSubways) {
	roomColor = #183331;
	backColor = #376658;
}

