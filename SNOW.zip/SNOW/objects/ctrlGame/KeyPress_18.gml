/// @description Insert description here
// You can write your code in this editor
global.gamePaused = !global.gamePaused;
//flags[eFlags.HAS_GLIDE] = !flags[eFlags.HAS_GLIDE];
