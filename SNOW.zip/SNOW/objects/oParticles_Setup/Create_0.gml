/// @description Insert description here
// You can write your code in this editor

partSystem = part_system_create_layer("weather",0);

#region Snow
partSnow = part_type_create();
part_type_sprite(partSnow,s_part_rain,false,false,false); //lastone true for random frames
//part_type_subimage(partSnow,1);
part_type_size(partSnow,1.6,2.2,0,0);
part_type_speed(partSnow,7,7.6,0,3); //myb wiggle?
part_type_alpha3(partSnow,0,1,0)
var _angle = 195;
var _diff = 5;
part_type_direction(partSnow,_angle-_diff,_angle+_diff,0,8);
part_type_life(partSnow,50,60);

partSnowDark = part_type_create();
part_type_sprite(partSnowDark,s_part_snow_dark,false,false,false); //lastone true for random frames
part_type_subimage(partSnowDark,0);
part_type_size(partSnowDark,1.2,1.9,0,0);
part_type_speed(partSnowDark,11,11.6,0,3); //myb wiggle?
part_type_alpha3(partSnowDark,1,1,0)
var _angle = 195;
var _diff = 20;
part_type_direction(partSnowDark,_angle-_diff,_angle+_diff,0,8);
part_type_life(partSnowDark,40,50);


partSnowSlow = part_type_create();
part_type_sprite(partSnowSlow,s_part_rain,false,false,false); //lastone true for random frames
part_type_size(partSnowSlow,1.1,1.3,0,0);
part_type_speed(partSnowSlow,0.15,0.3,0,0); //myb wiggle?
part_type_alpha3(partSnowSlow,0,1,0)
var _angle = 270;
var _diff = 20;
part_type_direction(partSnowSlow,_angle-_diff,_angle+_diff,0,2);
part_type_life(partSnowSlow,200,240);


partRain = part_type_create();
part_type_sprite(partRain,s_part_rain_subways,false,false,false); //lastone true for random frames
part_type_subimage(partRain,0);
part_type_size(partRain,1.2,1.6,0,0);
part_type_scale(partRain,6,0.5);
part_type_speed(partRain,2,2.5,0.3,0); //myb wiggle?
part_type_alpha3(partRain,0,1,1);
//part_type_gravity(partRain,0.2,270);
var _angle = 270;
var _diff = 2;
part_type_orientation(partRain,_angle,_angle,0,0,false)
part_type_direction(partRain,_angle-_diff,_angle+_diff,0,0);
part_type_life(partRain,40,50);




//
//partSnowBack = part_type_create();
//part_type_sprite(partSnowBack,s_part_snow_back,false,false,false); //lastone true for random frames
//part_type_subimage(partSnowBack,0);
//part_type_size(partSnowBack,1.2,1.6,0,0);
//part_type_speed(partSnowBack,3.2,3.6,0,0); //myb wiggle?
//part_type_alpha3(partSnowBack,0,1,0)
//var _angle = 195;
//var _diff = 5;
//part_type_direction(partSnowBack,_angle-_diff,_angle+_diff,0,3);
//part_type_life(partSnowBack,200,220);

//partSnowFront = part_type_create();
//part_type_sprite(partSnowFront,s_part_snow_front,false,false,false); //lastone true for random frames
//part_type_size(partSnowFront,1,1.3,0,0);
//part_type_speed(partSnowFront,1.6,1.9,0,0); //myb wiggle?
//
//var _angle = 205;
//var _diff = 5;
//part_type_direction(partSnowFront,_angle-_diff,_angle+_diff,0,2);
//part_type_life(partSnowFront,999,999);


//partSnowCloud = part_type_create();

#endregion
