/// @description Insert description here
// You can write your code in this editor

vspd = -0.5;

x += hspd;
y += vspd;