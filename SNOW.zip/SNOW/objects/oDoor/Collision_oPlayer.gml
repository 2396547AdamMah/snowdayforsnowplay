/// @description Insert description here
// You can write your code in this editor

ctrlGame.gotoRoom(dest,destX,destY,dir);