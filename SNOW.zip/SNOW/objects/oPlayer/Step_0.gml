/// @description Insert description here
// You can write your code in this editor
if (global.gamePaused || frozen) {
	if (image_speed > 0) {
		tempISpeed = image_speed;
	}
	image_speed = 0;
	exit;
} else if (image_speed == 0) {
	image_speed = tempISpeed;
}

//var _kRight = keyboard_check(vk_right)
	////var _kLeft = keyboard_check(vk_left)
	//var _kJump = keyboard_check_pressed(ord("Z"))
	////var _kJumpReleased = keyboard_check_released(ord("Z"))
	////var _kDown = keyboard_check(vk_down)
	////var _kUp = keyboard_check(vk_up)
	////var _kRun = keyboard_check(ord("J"))
	////var _kRunPressed = keyboard_check_pressed(ord("J"))
	////var _kGrab = keyboard_check(vk_up)
	////
//var _kThrow = keyboard_check_pressed(ord("X"));
//var _kRecall = keyboard_check_pressed(ord("C"));
//
//var _kMenu = keyboard_check(ord("S"))

if (Input.kJumpPressed) {
	jumpBuffer = PLAYER_BUFFER;
}
if (onGround()) {
	coyotime = PLAYER_BUFFER;
}

if (keyboard_check_pressed(vk_control)) {
	var _tool = inventory[inventoryIndex];
	if (_tool.spent) {
		if (_tool.name = "SPEAR" && _tool.spear.landed) {
			x = _tool.spear.x;
			y = _tool.spear.y;
			//hspd = _tool.spear.hspd;
			
			y = _tool.spear.y + 4;
			//glowObj.y = y;
			state = ePlayerState.CLIMB
			climbingOn = _tool.spear;
			hspd = 0;
			vspd = 0;
			fakeHspd = 0;
			//_tool.recall()
			
			//state = ePlayerState.FREE;

		}
	}
}


if (Input.kThrow && canThrow && !instance_exists(holdingItem)) {
	ThrowTool(inventoryIndex);
}
	
if (Input.kRecall && canRecall) {
	RecallTool(inventoryIndex);
}
//if (_kMenu) {
ToolMenu();

if (iframes > 0) {
	if (iframes % blinkDelay == 0) {
		blinking = !blinking;
	}
} else {
	blinking = false;
	if (!hittable) {
		hittable = true;
	}
}



oneWayTangible = true;
switch (state) {
	case ePlayerState.FREE:
		playerStateFree(id);
		break;
	case ePlayerState.EDGE_HANG:
		playerStateEdgeHang(id);
		break;
	case ePlayerState.CLIMB:
		playerStateClimbHang(id);
		break;
	case ePlayerState.WALK_POLE:
		playerStateWalkPole(id);
		break;
	
	case ePlayerState.CLIMB_WALL:
		playerStateClimbWall(id);
		break;
	case ePlayerState.CLIMB_WIRE:
		playerStateClimbWire(id);
		break;
	case ePlayerState.HOLD_RING:
		playerStateHoldRing(id);
		break;
	case ePlayerState.SWING:
		playerStateSwing(id);
		break;
	case ePlayerState.GLIDE:
		playerStateGlide(id);
		break;
	case ePlayerState.CRAWL:
		playerStateCrawl(id);
		break;
	case ePlayerState.NOCLIP:
		playerStateNoclip(id);
		break;
	case ePlayerState.SAVE:
		playerStateSave(id);
		break;
}

if (climbingOn != noone) {
	//climbingOn.image_blend = c_lime
	//climbingOn.image_alpha = 0.5;
}
//}

//
//if (spearObj != noone) {
	//var length = point_distance(x, y, spearObj.x,spearObj.y);
	//var middle_x = (x + spearObj.x) / 2;
	//// Set middle y to exact middle + weight of string
	//var middle_y = ((y + spearObj.y) / 2) + (length / 4);
	//
	//path_change_point(spearWire,0,x,y,5);
	//path_change_point(spearWire,1,middle_x,middle_y,100)
	//path_change_point(spearWire,2,spearObj.x,spearObj.y,5);
//}
if (state != ePlayerState.NOCLIP) {
	
var _hspd = hspd;
if (instance_exists(onObject)) {
	_hspd += onObject.hspd //*1.2;
	show_debug_message("HO")
} else {
	show_debug_message("HAI")
}	
	
if place_meeting(x+_hspd,y,tilemap)
{
    yplus = 0;
    while (place_meeting(x+_hspd,y-yplus,tilemap) && yplus <= abs(1*_hspd)) {
		yplus += 1;
	}
    if place_meeting(x+_hspd,y-yplus,tilemap)
    {
        while (!place_meeting(x+sign(_hspd),y,tilemap)) {
			x+=sign(_hspd);
			//glowObj.x += sign(_hspd)
		}
        _hspd = 0;
		if (state = ePlayerState.SWING) {
			ropeAngle = point_direction(grappleX,grappleY,x,y);
			ropeAngleVelocity = 0;
		}
    }
    else
    {
        y -= yplus;
		//glowObj.y -= yplus
    }
}
if (place_meeting(x + _hspd, y, oTunnelEntrance) && state != ePlayerState.CRAWL)
{
	while (!place_meeting(x+sign(_hspd),y,oTunnelEntrance)) 
	{
		x += sign(_hspd);
		//glowObj.y += sign(vspd)
	}
	_hspd = 0;
	hspd = 0;

}
if (place_meeting(x+_hspd, y, oElevator))
{
	while (!place_meeting(x+sign(_hspd),y,oElevator)) 
	{
		x += sign(_hspd);
	}
	_hspd = 0;
	hspd = 0;
}
	if (place_meeting(x+_hspd, y, oSaveStation))
{
	while (!place_meeting(x+sign(_hspd),y,oSaveStation)) 
	{
		x += sign(_hspd);
	}
	_hspd = 0;
	hspd = 0;
}

	
x += _hspd;
//glowObj.x += hspd;

// Downward slopes
if !place_meeting(x,y,tilemap) && vspd >= 0 && place_meeting(x,y+2+abs(hspd),tilemap)
{
	while(!place_meeting(x,y+1,tilemap)) {
		y += 1;
		//glowObj.y += 1;
	}
}
	
if (place_meeting(x, y+vspd, tilemap))
{
	while (!place_meeting(x,y+sign(vspd),tilemap)) 
	{
		y += sign(vspd);
		//glowObj.y += sign(vspd)
	}
	vspd = 0;

}

if (place_meeting(x, y+vspd, oTunnelEntrance) && state != ePlayerState.CRAWL)
{
	while (!place_meeting(x,y+sign(vspd),oTunnelEntrance)) 
	{
		y += sign(vspd);
		//glowObj.y += sign(vspd)
	}
	vspd = 0;

} 

//var _wall = collision_line(bbox_left,bbox_bottom+vspd,bbox_right,bbox_bottom+vspd,oOneWayPlatform,true,false);//instance_place(x,y+vspd,oOneWayPlatform);
var _wall = instance_place(x,y+vspd,oOneWayPlatform);
if (_wall != noone && vspd > 0 && bbox_bottom - 1 < _wall.bbox_top && oneWayTangible) {
	var _sign = instance_place(x,y+sign(vspd),oOneWayPlatform);
	while (_sign == noone) {
		y += sign(vspd);
		_sign = instance_place(x,y+sign(vspd),oOneWayPlatform);
	}
	vspd = 0;
} 
	
if (place_meeting(x, y+vspd, oElevator))
{
	while (!place_meeting(x,y+sign(vspd),oElevator)) 
	{
		y += sign(vspd);
		//glowObj.y += sign(vspd)
	}
	vspd = 0;

}
if (place_meeting(x, y+vspd, oSaveStation))
{
	while (!place_meeting(x,y+sign(vspd),oSaveStation)) 
	{
		y += sign(vspd);
		//glowObj.y += sign(vspd)
	}
	vspd = 0;

}

onObject = noone;	
//var _frisbee = instance_place(x,y+vspd,oFrisbee);
//if (_frisbee != noone) {
	//while (!place_meeting(x,y+sign(vspd),_frisbee)) 
	//{
		//y += sign(vspd);
		////glowObj.y += sign(vspd)
	//}
	//onObject = _frisbee;
	//vspd = 0;
//}	
var _frisbee = instance_place(x,y+vspd,oFrisbee);
if (_frisbee != noone && vspd > 0 
	&& bbox_bottom - 1 < _frisbee.bbox_top 
	&& oneWayTangible) {
	var _sign = instance_place(x,y+sign(vspd),oFrisbee);
	while (_sign == noone) {
		y += sign(vspd);
		_sign = instance_place(x,y+sign(vspd),oFrisbee);
	}
	vspd = 0;
	onObject = _frisbee;
} 	
//var _frisbee = instance_place(x,y+1,oFrisbee);
//if (_frisbee != noone) {
	//onObject = _frisbee;
//}
y+= vspd;
//glowObj.y += vspd;
}
else {
	x += hspd;
	y += vspd;
}
climbJumpBuffer = max(0, climbJumpBuffer-1);
coyotime = max(0, coyotime-1);
jumpBuffer = max(0, jumpBuffer-1);
edgeBuffer = max(0,edgeBuffer-1);
iframes = max(0,iframes-1);