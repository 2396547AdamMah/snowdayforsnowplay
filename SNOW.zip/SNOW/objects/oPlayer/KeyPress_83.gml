/// @description Insert description here
// You can write your code in this editor
//inventoryIndex++;
//if (inventoryIndex >= array_length(inventory)) {
	//inventoryIndex = 0;
//}