/// @description Insert description here
// You can write your code in this editor
tilemap = layer_tilemap_get_id("Collision");

if (room == rmDarkSnow) {
	instance_create_layer(x,y,"Fog",oSnowFog);
}