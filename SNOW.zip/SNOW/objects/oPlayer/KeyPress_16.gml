/// @description Insert description here
// You can write your code in this editor
//ThrowTool(inventoryIndex)
//iframes = iframesMax;
//hittable = false;
damage();