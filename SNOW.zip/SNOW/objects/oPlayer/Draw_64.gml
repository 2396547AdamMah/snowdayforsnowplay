/// @description Insert description here
// You can write your code in this editor

var _scale = oCam.camWidth/320;

for (var i = 0; i < hp; i++) {
	draw_sprite_ext(sPlayerHP,i % 3,
		4*_scale + i*(6*_scale), 4*_scale,
		_scale,_scale,0,lightColor,1);
}

for (var i = 0; i < array_length(inventory); i++) {
	_subImage = inventory[i].spent ? 0 : 1
	draw_sprite_ext(inventory[i].icon,_subImage,
		round((8*_scale) + i*(8*_scale)),round(24*_scale),
		_scale,_scale,0,toolColors[i],1);
}
draw_sprite_ext(sTool_MenuArrow,0,
	(8*_scale) + (8*_scale)*inventoryIndex,16*_scale,
	_scale,_scale,0,c_white,1)


//draw_text(8,8,$"H:{hspd}, V:{vspd}")
//draw_text(8,32,$"X:{x}, Y:{y}")
//
////draw_text(8,32,string(spears))
//draw_text(8,64,string(wireTouching))
//draw_text(8,96,string(currentSpearIndex))
//draw_text(8,128,$"ClimbingOn: {climbingOn}")