/// @description 
// You can write your code in this editor

//draw_set_colour(#4C5599)
//draw_set_colour(#191C33)
//if (javWireSet) { 
	//draw_line_width(javLine1.attachX,javLine1.attachY,javLine2.attachX,javLine2.attachY,1);
//} 
//draw_set_colour(c_white);

//if state = ePlayerState.SWING 
//{
	//draw_set_colour(#4C5599)
	//draw_line(grappleX,grappleY, x,y)
	//draw_set_colour(c_white);
//}
var _x = round(x);
var _y = round(y);

if (state = ePlayerState.GLIDE) {
	var _cond = vspd >= 2 ? 1 : 0
	var _image =  _cond ? 1 : 0
	draw_sprite_ext(sBunnyGlide,_image,round(x),round(y),
	image_xscale,image_yscale,image_angle,c_white,image_alpha);
}
//var _color = c_white;
//if (room == rmOutside || room = rmOutside_1) {
	//_color = #595D7F;
//} else if (room == rmDarkSnow) {
	//_color = #3D336C;
//} else if (room == rmDarkest) {
	//_color = #1D213D
//}
var _color = ctrlGame.roomColor;

var _alpha = blinking ? 0 : image_alpha;

draw_sprite_ext(sprite_index,image_index,_x,_y,
image_xscale,image_yscale,image_angle,_color,_alpha);
var _asset = $"{sprite_get_name(sprite_index)}_Glow";
//show_debug_message(_asset)
//show_debug_message(asset_get_index(_asset))

draw_sprite_ext(asset_get_index(_asset),image_index,_x,_y,
image_xscale,image_yscale,image_angle,lightColor,image_alpha)

if (keyboard_check(ord("S")) && array_length(inventory) > 0 ) {
	var _tool = inventory[inventoryIndex]
	draw_sprite(_tool.icon,!_tool.spent,round(x),round(y)-16);
}
