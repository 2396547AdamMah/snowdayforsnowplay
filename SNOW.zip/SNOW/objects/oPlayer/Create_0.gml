/// @description Insert description here
// You can write your code in this editor

//Myb hook that makes climbable rope
//placable spring

//myb inventory type deal with tools to traverse
//myb limited inventory space 3-4
//choose tool with s

//rope as perma upgrade (up+x?)
//teleport to spear, recalls spear tho
event_inherited();

#macro PLAYER_BUFFER 7
 
enum ePlayerState {
	FREE,
	CRAWL,
	EDGE_HANG,
	CLIMB,
	WALK_POLE,
	CLIMB_WALL,
	CLIMB_WIRE,
	HOLD_RING,
	GLIDE,
	SWING,
	NOCLIP,
	ELEVATOR,
	SAVE
}
grounded = false;
//enum ePlayerTools {
	//SPEAR,
	//JAVLINE,
	//SPRING
//}
onObject = noone;
lightColor = #ffff90;
iframes = 0;
iframesMax = 80;
blinking = false;
blinkDelay = 8;

hittable = true;

oneWayTangible = true;

tilemap = layer_tilemap_get_id("Collision");

lastSafeGround = instance_create_depth(x,y,depth-1,oPlayerSafeGround);

hp = 3;
heartPieces = 0;
heartPiecesMax = 4;

moveSpd = 2.4;
moveAccel = 0.3;
moveAccelAir = 0.2;
grav = 0.15;
wallGrav = 0.08;

jumpHeight = 3.2;

wallJumpH = 3;

isCrouched = false;
crawlSpeed = 1;
//crouchSpeed = 2.8;
//crouchAccel = 0.06;

crouchDashSpeed = 3.5;

climbingOn = noone;
climbSpeedH = 1.7;
climbSpeedFastH = 1.7;
climbAccel = 0.1;
climbAccelV = 0.2

fakeHspd = 0;
fakeVspd = 0;

climbSpeedV = 1.4;
climbSlideGrav = 0.06;
climbSlideGravDown = 0.06;
climbSlideGravMax = 8; 

climbJumpBuffer = 0;
climbJumpBufferMax = 6;
climbJumpBufferMaxDown = climbJumpBufferMax*2;

spearsLeft = 2;
spearAmount = 2; //for now, only works with one
currentSpearIndex = -1;
spearSpd = 11;
spears = array_create(0);

//inventory = [new ToolSpear(), new ToolJavline(), new ToolRope(), new ToolSpring()];
inventory = [new ToolSpear(), new ToolFrisbee()];
toolColors = [ #FF323A , #16E584,#3D5AFF,c_yellow, c_white, c_white];
inventoryIndex = 0;
canThrow = true;
canRecall = true;


javelinsLeft = 2;

//UNUSED
grappleX =0;
grappleY = 0;
ropeX = 0;
ropeY = 0;
ropeAngle = 0;
ropeAngleVelocity = 0
ropeLength = 0;

wireTouching = noone;

airJumpsLeft = 0;
airJumpsMax = 0;

hovering = false;
hoverGrav = 0.5;

#region Glide
glideLiftTimer = 0;
glideLiftDuration = 8;
glideLiftSpeed = 0.3;
glideToolIndex = 0;

glideSpeedH = moveSpd/1.3;
glideAccelH = moveAccel;

glideAccelV = 0.05;
glideSpeedV = 0.4;
glideSpeedDownV = glideSpeedV*6


#endregion

holdingItem = noone;

#region Buffers
coyotime = 0;
jumpBuffer = 0;
edgeBuffer = 0;

#endregion

hspd = 0;
vspd = 0;

dir = 1;

elevatorRiding = noone;
respawnPoint = new Vector2(0,0);

crouchSpd = 1;

inWater = false;
waterMoveSpeed = moveSpd * 0.9;
waterImageSpeedIdle = 0.2;
waterImageSpeedMoving = 0.4;
waterEnterDecel = 0.8;
waterLeaveDecel = 0.8;

function damage() {
	show_debug_message("HI")
	if (hittable) {
		show_debug_message("HI 2")
		hp--;
		iframes = iframesMax;
		hittable = false;
		return true;
	} else {
		show_debug_message("HI 3")
		return false;
	}
	
}

function checkEnterCrawl() {
	if (Input.kDown && onGround()) {
		isCrouched = true;
	}
	else isCrouched = false;
		
	if (isCrouched && place_meeting(x,y-4,tilemap)) {
		state = ePlayerState.CRAWL;
	}
	//var _rect = noone;
	//if (hspd > 0) {
		//_rect = collision_rectangle(bbox_left-2,bbox_top - 2,
			//bbox_right + 2 + hspd,bbox_bottom - 2,  tilemap,true,false);
	//} else if (hspd < 0) {
		//_rect = collision_rectangle(bbox_left - 2 + hspd,bbox_top - 2,
			//bbox_right+2,bbox_bottom - 2,  tilemap,true,false);
	//} else {
		//_rect = collision_rectangle(bbox_left - 2,bbox_top - 2,
			//bbox_right+2,bbox_bottom - 2, tilemap,true,false);
	//}
	//if (state == ePlayerState.FREE) {
		//if (_rect != noone && onGround()) {
			//state = ePlayerState.CRAWL;
			//isCrouched = true;
		//}
	//} else if (state == ePlayerState.CRAWL) {
		//if (_rect == noone) {
			//state = ePlayerState.FREE;
			//isCrouched = false;
		//}
	//}
	////if (_rect != noone ) {
		////state = ePlayerState.CRAWL;
		////isCrouched = true;
	////} else {
		////state = ePlayerState.FREE;
		////isCrouched = false;
	////}
}
function checkExitCrawl() {
	var _rect = noone;
	//if (hspd > 0) {
		//_rect = collision_rectangle(bbox_left-2,bbox_top - 2,
			//bbox_right + 2 + hspd,bbox_bottom - 2,  tilemap,true,false);
	//} else if (hspd < 0) {
		//_rect = collision_rectangle(bbox_left - 2 + hspd,bbox_top - 2,
			//bbox_right+2,bbox_bottom - 2,  tilemap,true,false);
	//} else {
	_rect = collision_rectangle(bbox_left - 2,bbox_top - 8,
		bbox_right + 2,bbox_bottom - 2, tilemap,true,false);
	//}
	if (_rect == noone ) {
		state = ePlayerState.FREE;
		//
		//if (!Input.kDown) {
			//isCrouched = false;	
		//}
		
	}
}

function executeJump(_jumpHeight = jumpHeight, _returnFree = false) {
	vspd = -jumpHeight;
	instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
	jumpBuffer = 0;
	coyotime = 0;
	if (_returnFree) state = ePlayerState.FREE;
}

function onGround() {
	var _oneWay = instance_place(x,y+1,oOneWayPlatform);
	if (_oneWay != noone && bbox_bottom-1 < _oneWay.bbox_top) {
		return true;
	}
	if (place_meeting(x,y+1,oElevator)) {
		return true
	}
	if (place_meeting(x,y+1,oSaveStation)) {
		return true
	}
	if (place_meeting(x,y+1,tilemap)) {
		return true
	}
	if (place_meeting(x,y,oWater)) {
		return true;
	}
	if (onObject != noone) {
		return true;
	}
	return false
}
function solidAboveYou() {

	if (place_meeting(x,y-2,oElevator)) {
		return true
	}
	if (place_meeting(x,y-2,oSaveStation)) {
		return true
	}
	if (place_meeting(x,y-2,tilemap)) {
		return true
	}
	return false
}
function onElevator() {
	return instance_place(x,y+1,oElevator);
}
function onSaveStation() {
	return place_meeting(x,y+1,oSaveStation);
}

function Save() {
	if (onSaveStation()) {
		if (Input.kDownPressed) {
			//ctrlGame.saveGame();
			respawnPoint.set(x,y);
			//state = ePlayerState.WAIT;
		}
	}
}

function groundReset() {
	////refill glide every climb? not sure
	glideLiftTimer = 0; 
}

function onWall() {
	if (place_meeting(x+1,y,oClimbableWall)) {
		return 1;
	}
	else if (place_meeting(x-1,y,oClimbableWall)) {
		return -1;
	}
	else return 0
}

function getWallTouching() {
	var _l = instance_place(x-1,y,oClimbableWall);
	var _r = instance_place(x+1,y,oClimbableWall);
	
	if (_l != noone) {
		return _l;
	} else return _r;
}
//TODO: rainworld spear throw and climb

state = ePlayerState.FREE

//glowObj = instance_create_depth(x,y,-999,oPlayerGlow)

javWire = path_add();
javWireSet = false;
grappleScout = noone;
// First anchor
path_add_point(javWire , 0,0, 100);
path_add_point(javWire , 0,0, 100);
path_set_kind(javWire , 0);
path_set_closed(javWire , 0);

function ThrowSpear() {
	var _offset = onGround() ? 4 : 0
	if (Input.kThrow && spearsLeft > 0) {
		var _spear = instance_create_depth(x,y-_offset,depth+1,oSpear,
			{owner:id, 
			index: array_length(spears)});
		with (_spear) {
			hspd = other.dir * other.spearSpd
		}
		array_push(spears,_spear);
		currentSpearIndex++;
		spearsLeft--;
	}
	
	
}

function ThrowTool(_index) {
	if (array_length(inventory) <= 0) {
		return -1;
	}
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _kDown = keyboard_check(vk_down)
	var _kUp = keyboard_check(vk_up)
	
	var _tool = inventory[_index]
	var _blend = toolColors[_index]
	switch (_tool.name) {
		case "SPEAR":
			_tool.shoot(id,new Vector2(dir*spearSpd,0),_blend);
			break;
		case "FRISBEE":
			_tool.shoot(id,new Vector2(dir,0),_blend);
			break;
		case "JAVLINE":
			
			if (_kDown) {
				_tool.shoot(id,new Vector2(0,6),_blend);
			} else if (_kUp) {
				_tool.shoot(id,new Vector2(dir*2,-4.5),_blend);
			} else {
				_tool.shoot(id,new Vector2(dir*4,-3),_blend);
			}
			
			break;
		case "ROPE":
			var _res = _tool.shoot(id,new Vector2(0,-16),_blend);
			if (_res != -1) {
				hspd = 0;
				vspd = 0;
			}
			break;
		
		case "SPRING":
			if (!onGround() && _kDown) {
				_tool.shoot(id,new Vector2(0,5),_blend);
			} else {
				_tool.shoot(id,new Vector2(dir*3,-0.5),_blend);
			}
			
			break;
		
		case "GLIDE":
			_tool.shoot(id,new Vector2(0,0));
			glideToolIndex = _index;
	}
	
	
}

function RecallTool(_index) {
	if (array_length(inventory) <= 0) {
		return -1;
	}
	var _tool = inventory[_index]
	_tool.recall(id);
}

function ThrowJavelin() { //TODO: update
	var _offset = onGround() ? 4 : 0
	var _kUp = keyboard_check(vk_up)
	var _kDown = keyboard_check(vk_down) 
	if (keyboard_check_pressed(ord("X")) && spearsLeft > 0) {
		var _jav = instance_create_depth(x,y-_offset,depth+1,oJavelin,
			{owner:id, 
			index: array_length(spears)});
		with (_jav) { 
			if (_kDown) {
				vspd = 8;
				//hspd = lengthdir_x(6,270+45*other.dir)
				//vspd = lengthdir_y(6,270+45*other.dir)
				image_angle = 270
			} else if (_kUp) {
				hspd = other.dir * 2.5
				vspd = -5;
			} else {
				hspd = other.dir * 5
				vspd = -1.5;
			}
				
			
		}
		//javelinsLeft--;
		array_push(spears,_jav);
		currentSpearIndex++;
		spearsLeft--;
		
		//DONT KEEP THIS, OBV WOULD CRASH THE GAME IF TWO DIFFERENT TOOLS
		if (currentSpearIndex == 1) {
			javLine1 = spears[0]
			javLine2 = spears[1]
			setupJavLine(javLine1,javLine2)
		}
	}
	//var _offset = onGround() ? 4 : 0
	//if (keyboard_check_pressed(ord("X")) && spearsLeft > 0) {
		//spearObj = instance_create_depth(x,y-_offset,depth+1,oSpear,{owner:id});
		//with (spearObj) {
			//hspd = lengthdir_x(other.spearSpd,90-45*other.dir)
			//vspd = lengthdir_y(other.spearSpd,90-45*other.dir)
			//image_angle = 90 - 45*other.dir
		//}
		//spearsLeft = 0;
	//}
}
function setupJavLine(jav1,jav2) {
	path_change_point(javWire,0,jav1.x,jav1.bbox_top,100)
	path_change_point(javWire,1,jav2.x,jav2.bbox_top,100)
	javWireSet = true;
}
function RecallSpear() {
	if (array_length(spears) <= 0) {
		return
	}
	if climbingOn == spears[0] {
		return
	}
	
	for (var i = 0; i < array_length(spears); i++) {
		//show_debug_message($"spears[{i}]: {spears[i]}")
	}
	if (Input.kRecall && array_length(spears) > 0) {
		//show_debug_message(spears[0].object_index);
		if (keyboard_check(vk_shift)) {
			for (var i = 0; i < array_length(spears); i++) {
				if (spears[i].landed) {
					spears[i].recall();
				}
			}
		}
		
		else if (instance_exists(spears[0])) {
			//instance_destroy(spearObj) //TODO: return anim, spin and fly back
			spears[0].recall();
		}
		
	}
	
}
function onRecall(_tool,_fumble) {
	//spearsLeft += 1;
	//array_delete(spears,array_get_index(spears,_tool),1);
	//array_delete(spears,_tool.index,1);
	//if (!_fumble) {
		//array_shift(spears) 
	//}
	//else array_pop(spears)
	
	//currentSpearIndex--;
	//owner.spears[] = noone;
	//javWireSet = false;
	//show_debug_message(_tool.object_index);
	instance_destroy(_tool);
}
function Swing() {
	//var _kRight = keyboard_check(vk_right)
	//var _kLeft = keyboard_check(vk_left)
	//var _input = _kRight - _kLeft;
	//
	//if (keyboard_check_pressed(vk_rshift)) {
		//var _dir = 90 + (-45 * _input);
		//var _pos = [0,0];
		//var _found = false;
		//for (var i = 0; i < 70; i++) {
			//var _coll = instance_place(x + lengthdir_x(i,_dir),
				//y + lengthdir_y(i,_dir),
				//oWall)
			//if (_coll) != noone {
				//_pos[0] = x + lengthdir_x(i,_dir)
				//_pos[1] = y + lengthdir_y(i,_dir)
				//_found = true;
				//break;
			//}
		//}
		//if (!_found) {
			//return;
		//} else {
			//grappleX = _pos[0];
			//grappleY = _pos[1];
			//ropeX = x;
			//ropeY = y;
			//ropeAngleVelocity = hspd*2;
			//ropeAngle = point_direction(grappleX,grappleY,x,y);
			//ropeLength = point_distance(grappleX,grappleY,x,y);
			//state = ePlayerState.SWING
		//}
	//}
	////if (keyboard_check_pressed(vk_rshift)) {
		////grappleX = x + 48*dir;
		////grappleY = y - 48;
		////ropeX = x;
		////ropeY = y;
		////ropeAngleVelocity = hspd
		////ropeAngle = point_direction(grappleX,grappleY,x,y);
		////ropeLength = point_distance(grappleX,grappleY,x,y);
		////state = ePlayerState.SWING
	////}
}

function Grab() {
	var _kGrab = Input.kGrab;
	var _climbable = instance_place(x,y,oClimbable) 
	if (_climbable != noone && _kGrab && climbJumpBuffer == 0) {
		y = _climbable.y + 4;
		//glowObj.y = y;
		state = ePlayerState.CLIMB
		climbingOn = _climbable;
		hspd = 0;
		vspd = 0;
		return true;
	}
	var _spear = instance_place(x,y,oSpear) 
	if (_spear != noone && _spear.landed && _kGrab && climbJumpBuffer == 0) {
		y = _spear.y + 4;
		//glowObj.y = y;
		state = ePlayerState.CLIMB
		climbingOn = _spear;
		hspd = 0;
		vspd = 0;
		fakeHspd = 0;
		return true;
	}

	_climbable = instance_place(x,y,oClimbablePole)
	if (_climbable != noone && _kGrab && climbJumpBuffer == 0) {
		x = _climbable.x;
		//glowObj.x = x;
		state = ePlayerState.CLIMB_WALL
		climbingOn = _climbable;
		hspd = 0;
		vspd = 0;
		fakeVspd = 0;
		return true;
	}
	_climbable = instance_place(x,y,oRingHold)
	if (_climbable != noone && _kGrab && climbJumpBuffer == 0) {
		x = _climbable.x;
		//glowObj.x = x;
		y = _climbable.y + 4;
		//glowObj.y = y;
		state = ePlayerState.HOLD_RING;
		climbingOn = _climbable;
		hspd = 0;
		vspd = 0;
		return true;
	}
	if (wireTouching != noone && _kGrab && climbJumpBuffer <= 0) {
		javWire = wireTouching;
		hspd = 0;
		vspd = 0;
		y = javWire.getY(x);
		state = ePlayerState.CLIMB_WIRE;
		return true;
	}
	return false;
}
function setGrapplePoint() {}

function ToolMenu() {
	//var _menuLeft = keyboard_check_pressed(ord("A"))
	//var _menuRight = keyboard_check_pressed(ord("S"))
	
	//if (_menuLeft) {
		//inventoryIndex--;
		//if (inventoryIndex < 0 ) {
			//inventoryIndex = array_length(inventory)-1;
		//}
	//} else 
	if (Input.kSwitchTool) {
		inventoryIndex++;
		if (inventoryIndex >= array_length(inventory)) {
			inventoryIndex = 0;
		}
	}
	
	//var _kRight = keyboard_check_pressed(ord("D"))
	//var _kLeft = keyboard_check_pressed(ord("A"))
	//var _kDown = keyboard_check_pressed(ord("W"))
	//var _kUp = keyboard_check_pressed(ord("S"))
	//
	//if (_kLeft && array_length(inventory) > 0) {
		//inventoryIndex = 0;
	//}
	//if (_kRight && array_length(inventory) > 1) {
		//inventoryIndex = 1;
	//}
	//if (_kUp && array_length(inventory) > 2) {
		//inventoryIndex = 2;
	//}
	//if (_kRight && array_length(inventory) > 3) {
		//inventoryIndex = 3;
	//}
}
tempISpeed = image_speed;