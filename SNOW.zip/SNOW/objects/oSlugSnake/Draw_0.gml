/// @description Insert description here
// You can write your code in this editor


// Inherit the parent event
event_inherited();
//shader_reset();
//draw_set_colour(c_white);
//draw_circle(x,y,playerDetectRange,true);
//draw_circle(x,y,playerLoseDetectRange,true);
//draw_path(ferretPath,x,y,true);
//shader_set(shd_colorReplace);