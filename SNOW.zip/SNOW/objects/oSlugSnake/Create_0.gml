/// @description Insert description here
// You can write your code in this editor
event_inherited();
function findClosestClimbable() {
	var _list =ds_list_create();
	var _climbables = collision_circle_list(x,y,240,oClimbablePole,false,true,_list,false);
	
	if (ds_list_size(_list) <= 0) {
		return -1;
	}
	var _closest = ds_list_find_value(_list,0);
	for (var i = 0; i < ds_list_size(_list); i++) {
		var _elem = ds_list_find_value(_list, i);
		var _distX = abs(x - _elem.x);
		var _distY = abs(y - _elem.y);
		
		if (_distX <= abs(x - _closest.x) 
			&& _distY <= abs(y - _closest.y)) {
			_closest = _elem;
		}
	}
	
	return _closest;

}
function findClimbablePath(_target = oPlayer) {
	var _dir = point_direction(x,y,_target.x,_target.y);
	var _dist = point_distance(x,y,_target.x,_target.y);
	var _final = [];
	if (climbingOn == noone) {
		var _closest = findClosestClimbable();
		if (_closest != -1) {
			_final = _closest.poleTouchingTreePlayer();
		}
	} else {
		_final = climbingOn.poleTouchingTreePlayer();
	}
	
	return _final;
	
	
}
numberParts = 24;
partScale = [1.4,1.5,1.5,1.4,1.3,1.3,1.3,1.3,1.3,1.3,1.2,1.1,1,
	0.9,0.8,0.7,0.7,0.7,0.6,0.6,0.5,0.5,0.4,0.3,0.3]

var _previous = id;
for (var i = 0; i < numberParts; i++) {
	var _scale = partScale[i]
	var _next = instance_create_depth(x,y + i*6,depth+i,oSlugBody, {
		previous: _previous,
		head: id,
		image_xscale: _scale,
		image_yscale: _scale
	});
	if (i % 2 == 0 && i < 8) {
		_next.hasWings = true;
	}
	//if (i == numberParts - 1 || i == numberParts - 2) {
		//_next.hasWings = true;
	//}
	_previous = _next;
}

state = "CLUELESS";
playerDetectRange = 160;
playerLoseDetectRange = 300;

target = oPlayer;
grav = 0.15
moveSpeed = 1.3;
moveAccel = 0.2;
climbingOn = noone;

climbSpeed = 1.6;


horiWanted = 0;
vertWanted = 0;
ferretPath = path_add();
setup = false;

poleDetectDistance = 64;
climbables = []
climbablesIndex = 0;
alarm[0] = 1;
time = 0;
var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})
current = new Vector2(0,0);