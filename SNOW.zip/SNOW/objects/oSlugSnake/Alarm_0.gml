/// @description Insert description here
// You can write your code in this editor
//if (!setup) {
	//
	//if (variable_global_exists("pathfindingGrid")) {
		//setup = true;
	//}
	//alarm[0] = 1;
//exit;
//}

//if (oPlayer.climbingOn != noone) {
	//var _climbables = findClimbablePath(oPlayer);
	//climbablesIndex = 0;
	//
	////if (_climbables != climbables) {
		////climbables = _climbables;
		////climbablesIndex = 0;
	////}
	////show_debug_message(climbables);
//} else {
	////climbables = [];
//}
//alarm[0] = 30;
if (state == "CRAWL") {
	path_delete(ferretPath);
	ferretPath = path_add();
	
	mp_grid_path(global.pathfindingGrid,ferretPath,x,y,oPlayer.x,oPlayer.y,true);
	
	var _dist = point_distance(x,y,oPlayer.x,oPlayer.y)
	//var _speed = _dist < 80 ? moveSpeed/1.3 : moveSpeed*1.2;
	
	//path_start(ferretPath,moveSpeed,path_action_stop,true);
	show_debug_message(ferretPath);
	
}
alarm[0] = 15;

//var _x = path_get_point_x(ferretPath,path_get_number(ferretPath)-1); 
//var _y = path_get_point_y(ferretPath,path_get_number(ferretPath)-1); 
//horiWanted = (oPlayer.x - x);
//vertWanted = (oPlayer.y - y);





