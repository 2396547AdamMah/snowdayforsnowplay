/// @description Insert description here
// You can write your code in this editor
hspd = 0;
vspd = 0;

function findPolesTouching() {
	var _list = ds_list_create();
	var _arr = []
	instance_place_list(x,y,oClimbablePole,_list,false);
	for (var i = 0; i < ds_list_size(_list); i++) {
		array_push(_arr, ds_list_find_value(_list,i));
	}
	ds_list_clear(_list);
	instance_place_list(x,y,oClimbable,_list,false);
	for (var i = 0; i < ds_list_size(_list); i++) {
		array_push(_arr, ds_list_find_value(_list,i));
	}
	return _arr;
}
function poleTouchingTreePlayer() {
	var _successfulRoutes = []
	var _num = 0;
	
	var _touching = findPolesTouching();
	//show_debug_message($"TOUCHING: {_touching}");
	for (var i = 0; i < array_length(_touching); i++) {
		//var _tree = instance_create_depth(0,0,-9999,oTreeHead);
		
		var _list = ds_list_create();
		ds_list_add(_list,id);
		var _foundPlayer = _touching[i].poleTouchingTreeNodePlayer(_list);
		show_debug_message($"LIST: {_list}, FOUND: {_foundPlayer}");
		if (_foundPlayer == 1) {

			for (var j = 0; j < ds_list_size(_list); j++) {
				_successfulRoutes[_num][j] = ds_list_find_value(_list,j);
			}
			_num++;
			
		}
		
		ds_list_destroy(_list);
		
	}
	if (array_length(_successfulRoutes) > 0) {
		show_debug_message(_successfulRoutes)
		var _trueRoute = _successfulRoutes[0];
		var _len = array_length(_successfulRoutes[0]);
		for (var i = 0; i < array_length(_successfulRoutes); i++) {
			if (array_length(_successfulRoutes[i]) < _len) {
				_trueRoute = _successfulRoutes[i];
				_len = array_length(_successfulRoutes[i]);
				show_debug_message(_len);
			}
		}
		return _trueRoute;
	} else return [];
	
	
	
	//return noone //_successfulRoutes;
	
}
function poleTouchingTree() {
	var _blacklist = [];
	var nodes = []
	array_push(_blacklist,id);
	
	
	var _touching = findPolesTouching();
	//show_debug_message($"TOUCHING: {_touching}");
	for (var i = 0; i < array_length(_touching); i++) {
		var _list = ds_list_create();
		ds_list_add(_list,id);
		//show_debug_message(_touching[i])
		_touching[i].poleTouchingTreeNode(_blacklist, _list);
		nodes[i] = []
		for (var j = 0; j < ds_list_size(_list); j++) {
			nodes[i][j] = ds_list_find_value(_list,j);
		}
		ds_list_destroy(_list);
		
	}
	
	return nodes;
	
}

function poleTouchingTreeNode(_blacklist,_list) {
	ds_list_add(_list,id);
	var _touching = findPolesTouching();
	
	for (var i = 0; i < array_length(_touching); i++) {
		if (ds_list_find_index(_list,_touching[i]) == -1) {
			_touching[i].poleTouchingTreeNode(_blacklist,_list);
		}
	}
}
function poleTouchingTreeNodePlayer(_list) {
	ds_list_add(_list,id);
	var _touching = findPolesTouching();
	
	if (oPlayer.climbingOn == id) {
		
		return true;
		
	}
	
	for (var i = 0; i < array_length(_touching); i++) {
		if (ds_list_find_index(_list,_touching[i]) == -1) {
			var _res = _touching[i].poleTouchingTreeNodePlayer(_list);
			if (_res) {
				return true;
			}
		}
	}
	return false;
}