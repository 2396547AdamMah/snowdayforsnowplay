/// @description Insert description here
// You can write your code in this editor
if (instance_exists(oSnowFog)) {
	if (oSnowFog.state != 0 || oSnowFog.state = -1) {
		oSnowFog.state = -1;
	}
} else {
	instance_create_layer(other.x,other.y,"Fog",oSnowFog);
}