/// @description Insert description here
// You can write your code in this editor
draw_set_colour(#261E4C);
draw_line(xstart,ystart,x,y);
draw_set_colour(c_white);
// Inherit the parent event
event_inherited();

