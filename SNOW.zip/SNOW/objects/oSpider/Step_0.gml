/// @description Insert description here
// You can write your code in this editor
if (ctrlGame.noSpidersMode) {
	instance_destroy();
	exit;
}

switch (state) {
	case "IDLE":
		lowerDelayTimer++;
		hspd = 0;
		vspd = 0;
		if (abs(x - oPlayer.x) < lowerRange && lowerDelayTimer > lowerDelay) {
			state = "ATTACK";
			lowerTimer = 0;
		}
		break;
	
	case "ATTACK":
		lowerTimer++;
		var _dir = -sign(x - oPlayer.x);
		vspd = lowerSpeedV;
		hspd = lowerSpeedH * _dir;
		
		if (lowerTimer > lowerMax) {
			state = "RISE";
		}
		if (place_meeting(x,y,oPlayer)) {
			state = "RISE";
		}
		if (onGround()) {
			state = "RISE";
		}
		break;
	
	case "RISE":
		vspd -= riseSpeed;
		x = lerp(x,xstart,0.1);
		if (place_meeting(x,y-1,tilemap)) {
			state = "IDLE";
			lowerDelayTimer = 0;
		}
		break;
}
// Inherit the parent event
event_inherited();

if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}