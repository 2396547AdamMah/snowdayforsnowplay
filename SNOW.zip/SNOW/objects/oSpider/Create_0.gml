/// @description Insert description here
// You can write your code in this editor
event_inherited();

lowerSpeedH = 1.4;
lowerSpeedV = 4;
lowerRange = 20;

lowerMax = 40;
lowerTimer = 0;

riseSpeed = 0.5;

lowerDelay = 40;
lowerDelayTimer = lowerDelay;

state = "IDLE";
var _asset = $"{sprite_get_name(sprite_index)}_Glow";
glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})

if (ctrlGame.noSpidersMode) {
	instance_destroy();
}