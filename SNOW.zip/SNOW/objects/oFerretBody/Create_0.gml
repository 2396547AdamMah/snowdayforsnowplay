/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

distancePrevious = 0;
distanceAllowed = 3;
pullSpeed = 1;

//grav = 0.4 * image_xscale;
grav = 0;
climbingOn = noone;
