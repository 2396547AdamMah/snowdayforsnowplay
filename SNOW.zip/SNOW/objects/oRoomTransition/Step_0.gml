/// @description Insert description here
// You can write your code in this editor
switch (fadeOut) {
	case -1:
		fadeTimer++;
		
		if (fadeTimer > fadeDelay) {
			image_alpha += fadeSpeed;
			fadeTimer = 0;
		}
		
		if (image_alpha >= 1) {
			fadeOut = 0;
		}
		
		break;
	
	case 0:
		//ctrlGame.gotoRoom(rmDarkSnow,120,3096,90);
		x = 0;
		y = 0;
		fadeOut = 1;
		
		//Room setup, player tp	
		break;
	
	case 1:
		fadeTimer++;
		
		if (fadeTimer > fadeDelay) {
			image_alpha -= fadeSpeed;
			fadeTimer = 0;
		}
		
		if (image_alpha <= 0) {
			instance_destroy();
		}
		
		break;
}