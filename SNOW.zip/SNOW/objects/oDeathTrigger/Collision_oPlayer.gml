/// @description Insert description here
// You can write your code in this editor


//TODO: death transition
with (other) {
	x = lastSafeGround.x;
	y = lastSafeGround.y;
	hspd = 0;
	vspd = 0;
}


