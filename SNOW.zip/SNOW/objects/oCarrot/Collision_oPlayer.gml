/// @description Insert description here
// You can write your code in this editor
ctrlGame.carrots += 1;
instance_destroy();