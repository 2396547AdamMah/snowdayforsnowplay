/// @description Insert description here
// You can write your code in this editor
alarm[0] = 1;
//global.paused=false
//global.pauseGame=true;
shake=0;
camAnim=false;

target = noone
camX = 0;
camY = 0;
pX=0;
pY=0;

camWidth = 0;
camHeight = 0;
dplyScale = 0;

camZone = noone;
noclip = false;
previousCamZone = noone;
vignette = false;
alpha = 0;