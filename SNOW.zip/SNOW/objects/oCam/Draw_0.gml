/// @description Insert description here
// You can write your code in this editor
//var _color = #C5CAE2;
//draw_set_alpha(alpha);
//draw_sprite_ext(sFogGradient,0,camX,camY,1,1,0,_color,alpha);
//draw_set_colour(c_white);
//draw_set_alpha(1);