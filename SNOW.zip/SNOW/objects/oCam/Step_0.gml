/// @description Insert description here
// You can write your code in this editor
//show_debug_message($"CAM <{camX}, {camY}")
if(instance_exists(target))
{
	with (target) {
		other.camZone = instance_place(x,y,oCamZone)
	}
	if (noclip) {
		camX= lerp(camX,(target.x-camWidth/2),0.2);
		camY= lerp(camY,(target.y-camHeight/2),0.2);
		camX = clamp(camX,0,room_width-camWidth);
		camY = clamp(camY,0,room_height-camHeight);
	} else {
		if (camZone != noone) {
			if (camZone != previousCamZone) {
				alarm[1] = 1;
				previousCamZone = camZone;
			}
			
			
			camX= lerp(camX,(target.x-camWidth/2),0.2);
			camY= lerp(camY,(target.y-camHeight/2),0.2);
			camX = clamp(camX,camZone.bbox_left,camZone.bbox_right-camWidth);
			camY = clamp(camY,camZone.bbox_top,camZone.bbox_bottom-camHeight);
		} else {
			camX = floor(target.x/320)*320;
			camY = floor(target.y/240)*240;
			camY = floor(target.y/240)*240;
		}
	}
	//camX = floor(target.x/320)*320;
	//camY = floor(target.y/240)*240;
	//camX= lerp(camX,(target.x-camWidth/2),0.2);
	//camY= lerp(camY,(target.y-camHeight/2),0.2);
	//camX = clamp(camX,0,room_width-camWidth);
	//camY = clamp(camY,0,room_height-camHeight);
}

camX+=random_range(-shake,shake);
camY+=random_range(-shake,shake);
shake*=0.9;//decay rate


camera_set_view_pos(view_camera[0],round(camX),round(camY));



if(keyboard_check_pressed(vk_f4))
{
window_set_fullscreen(!window_get_fullscreen());
}