/// @description Insert description here
// You can write your code in this editor
camX = 0;
camY = 0;
pX=0;
pY=0;

target = oPlayer;
if (!instance_exists(oPlayer)) {
	target = oPlayer
}


camWidth = 640;
camHeight = 480;
dplyScale = 3;

view_enabled = true;
view_visible[0] = true;

camera_set_view_size(view_camera[0],camWidth,camHeight);


dplyWidth = camWidth * dplyScale;
dplyHeigth = camHeight * dplyScale;

//window_set_caption("Bloodwood");
window_set_caption("snow");

window_set_size(dplyWidth,dplyHeigth);
surface_resize(application_surface,dplyWidth,dplyHeigth);

display_set_gui_size(camWidth,camHeight);
alarm[0] = 1;