/// @description Insert description here
// You can write your code in this editor
alpha = alpha == 0 ? 0.2 : 0