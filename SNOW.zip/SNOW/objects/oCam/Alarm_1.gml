/// @description Insert description here
// You can write your code in this editor
if (camZone.image_xscale > 1 && camZone.image_yscale > 1) {
	camWidth =  640;
	camHeight =  480;
} else {
	camWidth =  320
	camHeight =  240;
}

//camX = camZone.x;
//camY = camZone.y;

dplyScale = 3;

view_enabled = true;
view_visible[0] = true;

camera_set_view_size(view_camera[0],camWidth,camHeight);


dplyWidth = camWidth * dplyScale;
dplyHeigth = camHeight * dplyScale;


window_set_size(dplyWidth,dplyHeigth);
surface_resize(application_surface,dplyWidth,dplyHeigth);

display_set_gui_size(camWidth,camHeight);
//alarm[0] = 1;