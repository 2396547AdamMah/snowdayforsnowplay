/// @description Insert description here
// You can write your code in this editor

collBuffer--;

attachX = x - lengthdir_x(sprite_width/2,image_angle)
attachY = y - lengthdir_y(sprite_width/2,image_angle)

if (landed) {
	hspd = 0;
	vspd = 0;
} else if recalling {
	var _dir = point_direction(x,y,owner.x,owner.y);
	var _dist = point_distance(x,y,owner.x,owner.y);
	var _spd = max(4,_dist/8)
	
	hspd = lengthdir_x(_spd,_dir)
	vspd = lengthdir_y(_spd,_dir)
	
	if (place_meeting(x,y,owner)) {
		owner.onRecall(id, fumble)
	}
	
	image_angle += turnSpdMax;
	
	//turnSpd = min(turnSpdMax,turnSpd+turnSpdAccel);
} else {
	image_angle = point_direction(0,0,hspd,vspd);
	vspd += 0.15;
}
var _r = instance_place(x+1,y,oWall);
var _l = instance_place(x-1,y,oWall);

if (_r != noone && !recalling ) {
	
	//if _r.object_index == oWallSlope30 || _r.object_index == oWallSlope45 {
		fumble = true;
		struct.recall();
		//recall();
	//}

}
if (_l != noone && !recalling ) {
	
	//if _l.object_index == oWallSlope30 || _l.object_index == oWallSlope45 {
		fumble = true;
		struct.recall();
		//recall();
	//}

}


x += hspd;
if (collBuffer <= 0) {
	if (place_meeting(x, y+vspd, tilemap) && !recalling)
	{
		while (!place_meeting(x,y+sign(vspd),tilemap)) 
		{
			y += sign(vspd);
		}
		vspd = 0;
		if !recalling {
			landed = true;
			//show_debug_message(struct)
			struct.onLanded(id)
		}
}
}

y += vspd;

x = round(x);
y = round(y);

if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	if (place_meeting(x,y,oPlayer)) {
		glow.visible = false;
	} else glow.visible = true;
}