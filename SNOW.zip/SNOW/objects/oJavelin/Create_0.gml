/// @description Insert description here
// You can write your code in this editor
hspd = 0;
vspd = 0;

landed = false;


recalling = false;

turnSpd = 0;
turnSpdMax = 20;
turnSpdAccel = 5;
fumble = false;

collBuffer = 2;

attachX = x - lengthdir_x(sprite_width/2,image_angle)
attachY = y - lengthdir_y(sprite_width/2,image_angle)

function recall() {
	landed = false;
	recalling = true;
	image_index = 1;
}

tilemap = layer_tilemap_get_id("Collision");

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})