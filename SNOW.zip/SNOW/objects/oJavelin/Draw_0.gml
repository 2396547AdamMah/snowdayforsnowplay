/// @description Insert description here

draw_self()
// You can write your code in this editor
//draw_text(x,y,string(landed));
//draw_sprite(sRopeHook,0,attachX,attachY)