/// @description Insert description here
// You can write your code in this editor

if (instance_exists(previous)) {
	distancePrevious = point_distance(x,y,previous.x,previous.y);
	var _dir = point_direction(x,y,previous.x,previous.y);
	
	if (distancePrevious > distanceAllowed) {
		var _spd = distancePrevious - distanceAllowed;
		hspd = lengthdir_x(_spd/6,_dir);
		vspd = lengthdir_y(_spd/6,_dir);
	} else {
		hspd = lerp(hspd,0,0.2);
	}
}
vspd += grav;




// Inherit the parent event
event_inherited();

