/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

distancePrevious = 0;
distanceAllowed = 0;
pullSpeed = 1;

//grav = 0.4 * image_xscale;
grav = 0.15;
climbingOn = noone;

function toPrevious(_vec2) {
	if (instance_exists(previous)) {
		previous.hspd = _vec2.x;
		previous.vspd = _vec2.y;
	}
}