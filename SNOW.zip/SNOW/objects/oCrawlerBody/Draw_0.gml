/// @description Insert description here
// You can write your code in this editor
var _x = round(x);
var _y = round(y);

var _color = c_white;
if (room == rmOutside || room == rmOutside_1) {
	_color = #595D7F;
} else if (room == rmDarkSnow) {
	_color = #3D336C;
} else if (room == rmDarkest) {
	_color = #1D213D
}

draw_sprite_ext(sprite_index,image_index,_x,_y,
image_xscale,image_yscale,image_angle,_color,image_alpha);

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

draw_sprite_ext(asset_get_index(_asset),image_index,_x,_y,
image_xscale,image_yscale,image_angle,c_white,image_alpha)