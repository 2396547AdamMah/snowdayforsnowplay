/// @description Insert description here
// You can write your code in this editor
if !recalling {
	if other.object_index == oWallSlope30 || other.object_index == oWallSlope45 {
		fumble = true;
		struct.recall();
		//recall();
	}
	//else 
	//{
		//landed = true;
	//}
}
	
//instance_create_depth(x,y,depth,oClimbable, {image_xscale: 2});
//instance_destroy();