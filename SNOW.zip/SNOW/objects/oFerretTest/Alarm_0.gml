/// @description Insert description here
// You can write your code in this editor
if (oPlayer.climbingOn != noone) {
	climbables = findClimbablePath(oPlayer);
	//show_debug_message(climbables);
} else {
	climbables = [];
}
alarm[0] = 30;