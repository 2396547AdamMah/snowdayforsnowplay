/// @description Insert description here
// You can write your code in this editor
x = mouse_x;
y = mouse_y;

for (var i = 0; i < array_length(climbables); i++) {
	
	if (instance_exists(climbables[i])) {
		climbables[i].image_alpha = 0.5;
		climbables[i].image_blend = c_red;
	}

}

var _closest = findClosestClimbable();
if (_closest != -1 ) {
	_closest.image_alpha = 0.5;
	_closest.image_blend = c_green;
}
