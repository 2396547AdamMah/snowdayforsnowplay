/// @description Insert description here
// You can write your code in this editor
image_blend = ctrlGame.roomColor;
event_inherited();

if (isAlert) {
	draw_sprite(sDog_Alert,0,x,y-16);
}
//draw_circle(x,y,horizontalDetectRange,true);
//draw_circle(x,y,groundDetectRange,true);
//draw_circle(x,y,alreadyDetectedRange,true);