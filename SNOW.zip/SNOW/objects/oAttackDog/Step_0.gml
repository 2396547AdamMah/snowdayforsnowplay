/// @description Insert description here
// You can write your code in this editor


if (target == noone) {
	target = collision_circle(x,y,horizontalDetectRange,oPlayer,false,true);
	if (target != noone) {
		if (y - target.y > groundDetectRange) {
			target = noone;
		} 
	}
} else {
	target = collision_circle(x,y,alreadyDetectedRange,oPlayer,false,true);
}


switch (state) {
	case "IDLE":
		sprite_index = sDog_Idle;
		image_index = 0;
		image_speed = 0;
		hspd = lerp(hspd,0,moveDecel);
		
		if (target != noone) {
			state = "ALERT"
			image_xscale = sign(target.x - x);
			isAlert = true;
		}
		break;
	case "ALERT":
		alertTimer++;
		
		if (alertTimer > alertTime) {
			state = "DETECT";
			isAlert = false;
		}
		break;
	case "DETECT":
		if (target == noone) {
			state = "IDLE";
			alertTimer = 0;
			break;
		}
		if (target != noone) {
	
			aiming.set(target.x,target.y);
			var _dist = abs(x-aiming.x);
			var _dir = -sign(x - aiming.x);
			
			
			
			if (!jumping) {
				jumpTimer++;
				
				hspd = lerp(hspd,0,moveDecel);
				
				if (jumpTimer >= jumpDelay) {
					if (_dir == previousDir) {
						accSpeed += moveSpeedAccel;
					} else {
						previousDir = _dir;
						accSpeed = moveSpeedMin;
					}
					
					
					vspd = -decideJumpHeight(target) + random_range(-0.1,0.3);
					hspd = accSpeed*_dir + random_range(-0.2,0.2);
					if (_dir != 0) image_xscale = _dir * abs(image_xscale);
					
					jumping = true;
					instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
					sprite_index = sDog_Run;
					image_index = 0;
					image_speed = 0;
				}
			} else {
				jumpTimer = 0;
				
				hspd = lerp(hspd,(moveSpeedMin*_dir)/2,0.05);
				if (_dir != 0) image_xscale = _dir * abs(image_xscale);
				if (onGround()) {
					jumping = false;
					sprite_index = sDog_Run;
					image_index = 1;
					image_speed = 0;
					
				}
			}
			
		} 
		
		break;
}

if (abs(vspd) < 0.5) {
	vspd += grav/2;
}
else vspd += grav;

if (!jumping) {
	var _spear = instance_place(x + sign(image_xscale)*64,y,oSpear);
	
	if (_spear != noone && !_spear.recalling) {
		if (_spear.owner != noone) {
			target = _spear.owner;
			state = "DETECT";
		}
		vspd = -jumpHeightMax;
	}
}

// Inherit the parent event
event_inherited();

if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}