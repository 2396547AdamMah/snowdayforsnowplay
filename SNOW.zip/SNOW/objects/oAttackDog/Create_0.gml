/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();
sprite_index = sDog_Idle;
var _scale = random_range(0.9,1.2);

image_xscale *= _scale;
image_yscale *= _scale;

grav = 0.15;

dir = 1;
target = noone;
aiming = new Vector2();

jumping = false;
jumpTimer = 0;
jumpDelay = 5;

groundDetectRange = 48;
horizontalDetectRange = 120;
alreadyDetectedRange = 300;

jumpSpeed = 3.5;
moveSpeed = 2;

moveSpeedMin = 2;
moveSpeedMax = 3.3;
moveSpeedAccel = (moveSpeedMax - moveSpeedMin)/2;

jumpHeightMin = 1.5;
jumpHeightMax = 3;

moveDecel = 0.2;
moveTurnSpeed = 0.1;

state = "IDLE"
previousDir = 0;
accSpeed = moveSpeed;

isAlert = false;
alertTimer = 0;
alertTime = 12;

function decideJumpHeight(_target) {
	if (place_meeting(x + moveSpeedMax,y,tilemap)) {
		return jumpHeightMax;
	}
	if (_target != noone) {
		var _dist = y - _target.y;
		
		if (_dist > 24) {
			return jumpHeightMax/1.2;
		} else if (_dist > 12) {
			return jumpHeightMax/1.5;
		} 
	}
	return jumpHeightMin;
}
var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})