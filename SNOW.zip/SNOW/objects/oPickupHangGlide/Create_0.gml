/// @description Insert description here
// You can write your code in this editor
time = 0;
hspd = 0;
vspd = 0;