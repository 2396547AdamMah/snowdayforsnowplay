/// @description Insert description here
// You can write your code in this editor
ctrlGame.flags[eFlags.HAS_GLIDE] = true;
instance_destroy();