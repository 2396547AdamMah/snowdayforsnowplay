/// @description Insert description here
// You can write your code in this editor
//time++;
//
//var _amp = 0.3;
//var _period = 0.1;
//
//vspd = _amp * sin(_period * time); 

x += hspd;
y += vspd;