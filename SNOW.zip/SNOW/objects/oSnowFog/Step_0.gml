/// @description Insert description here
// You can write your code in this editor
image_blend = layer_background_get_blend(back);

x = oPlayer.x;
y = oPlayer.y;



switch (state) {
	case 1:
		if (image_xscale < scaleVanish) {
			image_xscale += growSpeed;
			image_yscale += growSpeed;
		} else {
			visible = false;
			state = -4;
		}
		break;
	case -1:
		if (image_xscale <= 1) {
			image_xscale = 1;
			image_yscale = 1;
			state = 0;
			visible = true;
		} else {
			image_xscale -= shrinkSpeed;
			image_yscale -= shrinkSpeed;
			visible = true;
		}
}