/// @description Insert description here
// You can write your code in this editor
enabled = true;

growSpeed = 0.15;
shrinkSpeed = 0.2;

scaleVanish = 5;

state = 0; //1: Grow & disapear// -1: appear & shrink //-4 fog gone
back = layer_background_get_id("Background")

