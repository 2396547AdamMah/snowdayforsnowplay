/// @description Insert description here
// You can write your code in this editor
state = visible ? 1 : -1;