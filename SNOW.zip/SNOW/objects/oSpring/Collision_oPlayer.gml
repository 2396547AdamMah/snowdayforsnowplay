/// @description Insert description here
// You can write your code in this editor
if (!recalling && landed) {
	other.y = bbox_top - 8
	other.hspd = 0;
	other.vspd = -4.5;
	other.groundReset();
	image_speed = 1;
}
