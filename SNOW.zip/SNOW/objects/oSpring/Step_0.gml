/// @description Insert description here
// You can write your code in this editor
if (landed) {
	hspd = 0;
	vspd = 0;
} else if recalling {
	var _dir = point_direction(x,y,owner.x,owner.y);
	var _dist = point_distance(x,y,owner.x,owner.y);
	var _spd = max(4,_dist/8)
	
	hspd = lengthdir_x(_spd,_dir)
	vspd = lengthdir_y(_spd,_dir)
	
	if (place_meeting(x,y,owner)) {
		owner.onRecall(id,fumble);
	}
	
	image_angle += turnSpdMax;
	//turnSpd = min(turnSpdMax,turnSpd+turnSpdAccel);
} else {
	vspd += 0.15;
}


if (place_meeting(x +hspd, y, tilemap) && !recalling) {
	while (!place_meeting(x + sign(hspd),y,tilemap)) {
		x += sign(hspd)
	}
	//landed = true;
	hspd = -hspd*0.7;
}

if (place_meeting(x , y + vspd, tilemap) && !recalling) {
	while (!place_meeting(x ,y + sign(vspd),tilemap)) {
		y += sign(vspd)
	}
	landed = true;
	vspd = 0;
}

x += hspd;
y += vspd;