/// @description Insert description here
// You can write your code in this editor
hspd = 0;
vspd = 0;

landed = false;

recalling = false;

turnSpd = 0;
turnSpdMax = 20;
turnSpdAccel = 5;
fumble = false;

tilemap = layer_tilemap_get_id("Collision");

image_speed = 0;

function recall() {
	landed = false;
	recalling = true;
	sprite_index = sSpringRecall;
}