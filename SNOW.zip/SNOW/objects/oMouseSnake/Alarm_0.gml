/// @description Insert description here
// You can write your code in this editor



path_delete(ferretPath);
ferretPath = path_add();

var _rangeX = choose(-8,0,8);
var _rangeY = choose(-8,0,8);
mp_grid_path(global.backWallGrid,
ferretPath,x,y,target.x + _rangeX,target.y + _rangeY,false);

path_start(ferretPath,moveSpeed,path_action_stop,true);

alarm[0] = 30;


