/// @description Insert description here
// You can write your code in this editor
event_inherited();

numberParts = 6;
partScale = [1.5,1.3,1.15,1,0.9,0.8]
var _previous = id;
for (var i = 0; i < numberParts; i++) {
	var _scale = partScale[i]
	var _next = instance_create_depth(x,y + i*6,depth+i,oMouseSnake_Body, {
		previous: _previous,
		head: id,
		image_xscale: _scale,
		image_yscale: _scale
	});
	_previous = _next;
}

state = "CRAWL";
target = oPlayer;
grav = 0.15
moveSpeed = 1.6;
moveAccel = 0.2;
climbingOn = noone;

climbSpeed = 1.6;


horiWanted = 0;
vertWanted = 0;
ferretPath = path_add();
setup = false;

poleDetectDistance = 64;

climbablesIndex = 0;
alarm[0] = 1;

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})