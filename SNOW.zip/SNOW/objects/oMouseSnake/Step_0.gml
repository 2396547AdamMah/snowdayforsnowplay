/// @description Insert description here
// You can write your code in this editor

//show_debug_message(tilemap_get_at_pixel(tilemap,mouse_x,mouse_y))

switch (state) {
	case "CRAWL":
		image_angle = direction;
		direction += irandom(5) * choose(-1,1);
		break;
}
//if (Input.kLeft) {
	//hspd = -2;
//} else if (Input.kRight) {
	//hspd = 2;
//} else hspd = 0;
//x = mouse_x;
//y = mouse_y;

// Inherit the parent event
event_inherited();

x = round(x);
y = round(y);
//var _visible = (collision_circle(x,y,128,oPlayer,false,false) != noone);
if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	//glow.visible = _visible;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}
