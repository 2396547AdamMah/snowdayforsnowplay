/// @description Insert description here
// You can write your code in this editor
hspd = 0;
vspd = 0;
show_debug_message("OH HAII")
//landed = false;
vertical = false;

recalling = false;
moveSpeed = 1.4

tilemap = layer_tilemap_get_id("Collision");

function recall() {
	landed = false;
	recalling = true;
	image_index = 1;
}

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})
image_blend = ctrlGame.roomColor;