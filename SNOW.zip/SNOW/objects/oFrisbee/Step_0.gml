/// @description Insert description here
// You can write your code in this editor

if recalling {
	var _dir = point_direction(x,y,owner.x,owner.y);
	var _dist = point_distance(x,y,owner.x,owner.y);
	var _spd = max(4,_dist/8)
	
	hspd = lengthdir_x(_spd,_dir)
	vspd = lengthdir_y(_spd,_dir)
	
	if (place_meeting(x,y,owner)) {
		owner.onRecall(id,false);
	}
	
} else {
	hspd = moveSpeed * dir;
}
//var _r = instance_place(x+1,y,oWall);
//
//if (_r != noone && !recalling ) {
	//
	////if _r.object_index == oWallSlope30 || _r.object_index == oWallSlope45 {
		//fumble = true;
		//struct.recall();
		////recall();
	////}
//
//}


if (place_meeting(x +hspd, y, tilemap) && !recalling) {
	while (!place_meeting(x + sign(hspd),y,tilemap)) {
		x += sign(hspd)
	}
	struct.recall();
	hspd = 0;
}

x += hspd;
y += vspd;

//x = round(x);
//y = round(y);

if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	if (place_meeting(x,y,oPlayer)) {
		glow.visible = false;
	} else glow.visible = true;
}
