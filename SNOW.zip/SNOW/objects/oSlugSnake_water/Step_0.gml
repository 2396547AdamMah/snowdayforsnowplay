/// @description Insert description here
// You can write your code in this editor

//show_debug_message(tilemap_get_at_pixel(tilemap,mouse_x,mouse_y))
time++;
switch (state) {
	case "CLUELESS":
		var _detect = collision_circle(x,y,playerDetectRange,oPlayer,false,false);
		if (_detect != noone) {
			state = "CRAWL";
			
		}
		hspd = 0;
		vspd = 0;
		
		break;
	case "CRAWL":
		var _detect = collision_circle(x,y,playerLoseDetectRange,oPlayer,false,false);
		
		if (_detect == noone) {
			state = "CLUELESS";
		}
			var _move = new Vector2(oPlayer.x - x, oPlayer.y - y);
			var _speed = max(1,point_distance(x,y,oPlayer.x,oPlayer.y)/38);
			//var _speed = abs(oPlayer.x - x) < 80 ? moveSpeed/1.3 : moveSpeed*1.2;
			
			var _angle = angleLerp(current.dir(),_move.dir(),0.1);
			//show_debug_message(_angle);
			current.setPolar(_speed,_angle);
		
			show_debug_message(current);
			//_move = _move.normalized().multiply(_speed);
			//var _s = 120 * sin(80 * time);
			//current.setPolar(current.len(),current.dir() + _s)

			hspd = lerp(hspd,current.x,0.1);
			if (place_meeting(x,y - (12*image_xscale),oWater)) {
				vspd = lerp(vspd,current.y,0.1);
			}
			
			image_angle = current.dir();
			//hspd = lerp(hspd,_move.x,moveAccel);
			//vspd = lerp(vspd, _move.y, moveAccel);
		
		//vspd += grav;
		
		
		break;
}
if (!place_meeting(x,y,oWater)) {
	vspd += grav;
}
//if (Input.kLeft) {
	//hspd = -2;
//} else if (Input.kRight) {
	//hspd = 2;
//} else hspd = 0;
//x = mouse_x;
//y = mouse_y;

// Inherit the parent event
event_inherited();
//x = round(x);
//y = round(y);
//var _visible = (collision_circle(x,y,128,oPlayer,false,false) != noone);
if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	//glow.visible = _visible;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}