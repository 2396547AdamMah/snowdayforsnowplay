/// @description Insert description here
// You can write your code in this editor
event_inherited();
climbables = [];

function findClosestClimbable() {
	var _list =ds_list_create();
	var _climbables = collision_circle_list(x,y,240,oClimbablePole,false,true,_list,false);
	
	if (ds_list_size(_list) <= 0) {
		return -1;
	}
	var _closest = ds_list_find_value(_list,0);
	for (var i = 0; i < ds_list_size(_list); i++) {
		var _elem = ds_list_find_value(_list, i);
		var _distX = abs(x - _elem.x);
		var _distY = abs(y - _elem.y);
		
		if (_distY < abs(y - _closest.y)) {
			_closest = _elem;
		}
	}
	
	return _closest;

}
//TODO: this dont work dont know why
function findClimbablePath(_target = oPlayer) {
	var _dir = point_direction(x,y,_target.x,_target.y);
	var _dist = point_distance(x,y,_target.x,_target.y);
	var _final = [];
	if (climbingOn == noone) {
		var _closest = findClosestClimbable();
		//show_debug_message(_closest);
		if (_closest != -1) {
			_final = _closest.poleTouchingTreePlayer();
		}
	} else {
		_final = climbingOn.poleTouchingTreePlayer();
	}
	
	//var _closest = 
	//var _climbables = collision_circle_list(x,y,240,oClimbablePole,false,true,_list,false);
	//var _nodes = []; //idk;
	return _final;
	
	
}

function findClimbable(_elem,_list) {
	array_push(_list,_elem);
	//show_debug_message(_elem);
	//show_debug_message($"P {oPlayer.climbingOn}")
	var _final = [];
	
	
	var _playerDetected = (oPlayer.climbingOn == _elem);
	//show_debug_message(_playerDetected);


	var _climbables = _elem.findPolesTouching();
	
	//show_debug_message(_climbables);
	if (array_length(_climbables) > 0) {
		for (var i = 0; i < array_length(_climbables); i++) {
			for (var j = 0; j < array_length(_list); j++) {
				if (_climbables[i] == _list[j]) {
					//show_debug_message("wooper")
					return {
						foundPlayer: false,
						list: []
					}
				}
			} 
			
			
			var _res = findClimbable(_climbables[i], _list);
			if (_res.foundPlayer) {
				_final = _res.list;
				
				//show_debug_message($"{_final}/ {_res.list}")
				array_push(_final,_climbables[i]);
				break;
			}
		}
	}
	
	return {
		foundPlayer: _playerDetected,
		list: _final
	
	};
		//var _listV = ds_list_create();
		//var _listH = ds_list_create(); 
		//collision_rectangle_list(_elem.bbox_left,_elem.bbox_top,
			//_elem.bbox_right,_elem.bbox_bottom, oClimbable,false,false,_listV,false);
		//
		//if (ds_list_size(_listV) > 0) {
			//for (var i = 0; i < ds_list_size(_listV); i++) {
				//if (ds_list_find_value(_listV,i) != _elem) {
					//var _res = findClimbable(ds_list_find_value(_listV,i),_elem);
					//if (_res.foundPlayer) {
						//
						//_final = _res.list;
						//array_push(_final,ds_list_find_value(_listV,i));
						//ds_list_destroy(_listV);
						//ds_list_destroy(_listH);
						//return {
							//foundPlayer: true,
							//list: _final
						//}
					//}
				//}
				//
			//}
		//}
	//
		//collision_rectangle_list(_elem.bbox_left,_elem.bbox_top,
			//_elem.bbox_right,_elem.bbox_bottom, oClimbable,false,false,_listH,false);
		//
		//if (ds_list_size(_listH) > 0) {
			//for (var i = 0; i < ds_list_size(_listH); i++) {
				//if (ds_list_find_value(_listH,i) != _elem) {
					//var _res = findClimbable(ds_list_find_value(_listH,i),_elem);
					//if (_res.foundPlayer) {
						//_final = _res.list;
						//array_push(_final,ds_list_find_value(_listH,i));
						//ds_list_destroy(_listV);
						//ds_list_destroy(_listH);
						//return {
							//foundPlayer: true,
							//list: _final
						//}
					//}
				//}
			//}
		//}
		//ds_list_destroy(_listV);
		//ds_list_destroy(_listH);
	//
	//return {
		//list: _final,
		//foundPlayer: false
	//};
}

function findClimbable2(_elem,_list) {

	//show_debug_message(_elem);
	//show_debug_message($"P {oPlayer.climbingOn}")
	var _final = [];
	
	
	var _playerDetected = (oPlayer.climbingOn == _elem);
	show_debug_message(_playerDetected);

	var _climbables = _elem.findPolesTouching();
	
	//show_debug_message(_climbables);
	if (array_length(_climbables) > 0) {
		for (var i = 0; i < array_length(_climbables); i++) {
			for (var j = 0; j < array_length(_list); j++) {
				if (_climbables[i] == _list[j]) {
					return {
						foundPlayer: false,
						list: []
					}
				}
			} 
			array_push(_list,_elem);
			//show_debug_message(_list);
			var _res = findClimbable(_climbables[i], _list);
			if (_res.foundPlayer) {
				array_copy(_final,0,_res.list,0,array_length(_res.list));
				//show_debug_message($"{_final}/ {_res.list}")
				array_push(_final,_climbables[i]);
				break;
			}
		}
	}
	
	return {
		foundPlayer: _playerDetected,
		list: _final
	
	};
}

numberParts = 6;
partScale = [1.3,1.3,1.15,1,0.9,0.8]
var _previous = id;
for (var i = 0; i < numberParts; i++) {
	var _scale = partScale[i]
	var _next = instance_create_depth(x,y + i*6,depth+i,oFerretBody, {
		previous: _previous,
		head: id,
		image_xscale: _scale,
		image_yscale: _scale
	});
	_previous = _next;
}

state = "CRAWL";
target = oPlayer;
grav = 0.15
moveSpeed = 1.8;
moveAccel = 0.2;
climbingOn = noone;

climbSpeed = 1.6;


horiWanted = 0;
vertWanted = 0;
ferretPath = path_add();
setup = false;

poleDetectDistance = 64;

climbablesIndex = 0;
alarm[0] = 1;