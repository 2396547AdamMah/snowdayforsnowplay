/// @description Insert description here
// You can write your code in this editor

//show_debug_message(tilemap_get_at_pixel(tilemap,mouse_x,mouse_y))

switch (state) {
	case "CRAWL":
		if (target != noone) {

			if (array_length(climbables) > 0 && !array_length(climbables) <= climbablesIndex+1) {
				//var _dir = sign(climbables[0].x - x);
				var _pole = climbables[climbablesIndex+1];
				var _dir = (_pole.x - x);
				hspd = lerp(hspd,moveSpeed * _dir,moveAccel);
				show_debug_message("HI")
				var _poleV = instance_place(x,y,_pole);
				if (_poleV != noone) {
					climbablesIndex++;
					state = "CLIMB_POLE";
					climbingOn = _pole;
					
					hspd = 0;
					x = _poleV.x;
				}
				
			} else {
				
				hspd = lerp(hspd,moveSpeed * sign(horiWanted),moveAccel);
			}
		}
		vspd += grav;
		
		
		break;
	case "CLIMB_POLE":
		var _dir = 0;
		
		if (array_length(climbables) > climbablesIndex+1) {
			_dir = (climbables[climbablesIndex+1].y - y);
			vspd = lerp(vspd,climbSpeed * _dir,moveAccel);
			
			var _poleH = instance_place(x,y,oClimbable);
			if (_poleH != noone) {
				state = "CLIMB_HANG";
				vspd = 0;
				y = _poleH.y+2;
				climbingOn = _poleH;
				climbablesIndex++;
			}
			
		} else {
			_dir = sign(oPlayer.y - y);
			vspd = lerp(vspd,climbSpeed * _dir,moveAccel);
		}
		
		
		y = clamp(y,climbingOn.bbox_top,climbingOn.bbox_bottom);
		
		
		break;
	
	case "CLIMB_HANG":
		//var _dir = sign(oPlayer.x - x);
		var _dir = 0;
		
		if (array_length(climbables) > climbablesIndex+1) {
			_dir = (climbables[climbablesIndex+1].x - x);
			hspd = lerp(hspd,climbSpeed * _dir,moveAccel);
			
			var _poleV = instance_place(x,y,oClimbablePole);
			if (_poleV != noone) {
				state = "CLIMB_POLE";
				climbingOn = _poleV;
				climbablesIndex++;
				hspd = 0;
				x = _poleV.x;
			}
		} else {
			_dir = sign(oPlayer.x - x);
			hspd = lerp(hspd,climbSpeed * _dir,moveAccel);
		}
		//hspd = lerp(hspd, climbSpeed * sign(horiWanted), moveAccel);
		x = clamp(x,climbingOn.bbox_left,climbingOn.bbox_right);
		
		
		
		break;
}
//if (climbingOn != noone) {
	//climbingOn.image_alpha = 0.5;
	//climbingOn.image_blend = c_red;
//}

for (var i = 0; i < array_length(climbables); i++) {
	
	if (instance_exists(climbables[i])) {
		climbables[i].image_alpha = 0.5;
		climbables[i].image_blend = c_red;
	}

}

var _closest = findClosestClimbable();
if (_closest != -1 ) {
	_closest.image_alpha = 0.5;
	_closest.image_blend = c_green;
}

//if (Input.kLeft) {
	//hspd = -2;
//} else if (Input.kRight) {
	//hspd = 2;
//} else hspd = 0;
//x = mouse_x;
//y = mouse_y;

// Inherit the parent event
event_inherited();

