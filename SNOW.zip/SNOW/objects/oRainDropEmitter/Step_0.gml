/// @description Insert description here
// You can write your code in this editor
timer++;
amountReal = amount * min(1,round(image_xscale/1.5))
delayReal = delay / max(1,image_xscale/3)
if (timer >= delayReal) {
	for (var i = 0; i < amountReal; i++) {
		instance_create_depth(
		irandom_range(bbox_left,bbox_right),
		bbox_bottom-4,
		depth+1,oFX,
		{sprite:s_fx_drop})
	}
	timer = 0;
}