/// @description Insert description here
// You can write your code in this editor

if (instance_exists(previous)) {
	distancePrevious = point_distance(x,y,previous.x,previous.y);
	var _dir = point_direction(x,y,previous.x,previous.y);
	
	if (distancePrevious > distanceAllowed) {
		var _spd = distancePrevious - distanceAllowed;
		hspd = lengthdir_x(_spd/2,_dir);
		vspd = lengthdir_y(_spd/2,_dir);
		image_angle = angleLerp(image_angle,_dir - 90,0.2);
		//image_angle = angleLerp(image_angle,_dir,0.2);
		
	} else {
		hspd = lerp(hspd,0,0.2);
	}
}
if (head.state == "CLIMB_POLE" || head.state == "CLIMB_HANG") {
	if (place_meeting(x,y,head.climbingOn)) {
		climbingOn = head.climbingOn;
	}
	if (climbingOn != head.climbingOn) {
		climbingOn = noone;
	}
}
if (climbingOn != noone) {
	y = clamp(y,climbingOn.bbox_top,climbingOn.bbox_bottom);
	x = clamp(x,climbingOn.bbox_left,climbingOn.bbox_right);
	
	if (head.climbingOn == noone) {
		climbingOn = noone;
	}
} else {
	vspd += grav;
}



// Inherit the parent event
event_inherited();


if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	//glow.visible = _visible;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}