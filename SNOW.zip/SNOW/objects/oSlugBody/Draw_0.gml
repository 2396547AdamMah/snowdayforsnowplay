/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

if (hasWings) {
	draw_sprite_ext(sSlugCircle_wings,0,x,y,
		image_xscale,image_yscale,image_angle,image_blend,image_alpha);
}