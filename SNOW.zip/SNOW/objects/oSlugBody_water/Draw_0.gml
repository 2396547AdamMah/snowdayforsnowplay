/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

if (hasWings > 0) {
	var _wings = hasWings > 1 ? sSlugCircle_Water_Wings : sSlugCircle_Water_Wings_Small
	draw_sprite_ext(_wings,0,x,y,
		image_xscale,image_yscale,image_angle,image_blend,image_alpha);
}