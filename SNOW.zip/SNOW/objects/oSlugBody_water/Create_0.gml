/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

distancePrevious = 0;
distanceAllowed = 3 * image_xscale;
if (image_xscale < 0.6) {
	distanceAllowed = 1;
}

pullSpeed = 1;

//grav = 0.4 * image_xscale;
grav = 0.4;
climbingOn = noone;

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_layer(x,y,"Glow",oGlow,{
	sprite_index: asset_get_index(_asset),
	//image_blend: other.image_blend,
	owner: id
})
hasWings = 0;
tangible = false;