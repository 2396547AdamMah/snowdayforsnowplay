/// @description Insert description here
// You can write your code in this editor
if (global.gamePaused) {
	exit;
}
//LATER
//raindropTimer++;
//
//if (raindropTimer >= raindropDelay) {
	//var _x = irandom_range(bbox_left+4,bbox_right-4);
	//instance_create_depth(_x,bbox_bottom,depth-1,oFX,{sprite: sWaterSplash})
	//raindropTimer = 0;
//}