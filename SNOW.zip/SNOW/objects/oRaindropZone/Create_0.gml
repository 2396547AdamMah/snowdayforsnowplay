/// @description Insert description here
// You can write your code in this editor
raindropTimer = 0;
raindropDelay = 8 / (image_xscale/24);
