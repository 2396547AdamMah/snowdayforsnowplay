/// @description Insert description here
// You can write your code in this editor
switch (dir) {
	case 0:
		if (place_meeting(x,y,oPlayer)) {
			//TODO: do shit
		}
		break;
}