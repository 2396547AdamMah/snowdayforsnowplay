/// @description Insert description here
// You can write your code in this editor
dir = 0;

colorInitial = #B7B9CC;
colorFinal = #ffB9CC;

transAmount = 0.2;