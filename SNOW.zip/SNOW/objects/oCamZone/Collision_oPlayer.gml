/// @description Insert description here
// You can write your code in this editor
if (backColor != -1 && oCam.camZone == id) {
	
	layer_background_blend(back,backColor);
} 
if (layer_background_get_blend(back) != ctrlGame.backColor && backColor == -1 && oCam.camZone == id) {
	layer_background_blend(back,ctrlGame.backColor);
}