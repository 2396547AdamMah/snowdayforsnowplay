/// @description Insert description here
// You can write your code in this editor
back = layer_background_get_id("Background");