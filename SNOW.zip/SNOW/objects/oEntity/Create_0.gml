/// @description Insert description here
// You can write your code in this editor
//TODO: springNonTool
hspd = 0;
vspd = 0;

tangible = true;
frozen = false; 
oneWayTangible = true;
tilemap = layer_tilemap_get_id("Collision");

function onGround() {
	var _oneWay = instance_place(x,y+1,oOneWayPlatform);
	if (_oneWay != noone && bbox_bottom-1 < _oneWay.bbox_top) {
		return true;
	}
	if (place_meeting(x,y+1,tilemap)) {
		return true
	}
	return false;
}

function collisionsX() {
	if place_meeting(x+hspd,y,tilemap) {
		yplus = 0;
		while (place_meeting(x+hspd,y-yplus,tilemap) && yplus <= abs(1*hspd)) {
			yplus += 1;
		}
		if place_meeting(x+hspd,y-yplus,tilemap)
		{
			while (!place_meeting(x+sign(hspd),y,tilemap)) {
				x+=sign(hspd);
				//glowObj.x += sign(hspd)
			}
			hspd = 0;
		}
		else
		{
			y -= yplus;
		}
	}
}

function collisionsY() {
	// Downward slopes
	if !place_meeting(x,y,tilemap) && vspd >= 0 && place_meeting(x,y+2+abs(hspd),tilemap)
	{
		while(!place_meeting(x,y+1,tilemap)) {
			y += 1;
			//glowObj.y += 1;
		}
	}
		
	if (place_meeting(x, y+vspd, tilemap))
	{
		while (!place_meeting(x,y+sign(vspd),tilemap)) 
		{
			y += sign(vspd);
			//glowObj.y += sign(vspd)
		}
		vspd = 0;
	
	}
	
	var _wall = instance_place(x,y+vspd,oOneWayPlatform);
	if (_wall != noone && vspd >= 0) {
		var _sign = instance_place(x,y+sign(vspd),oOneWayPlatform);
		while (_sign == noone) {
			y += sign(vspd);
			_sign = instance_place(x,y+sign(vspd),oOneWayPlatform);
		}
			vspd = 0;
	}	
	var _oneWay = instance_place(x,y+vspd,oOneWayPlatform);
	if (_oneWay != noone && vspd > 0 && bbox_bottom - 1 < _oneWay.bbox_top && oneWayTangible) {
		var _sign = instance_place(x,y+sign(vspd),oOneWayPlatform);
		while (_sign == noone) {
			y += sign(vspd);
			_sign = instance_place(x,y+sign(vspd),oOneWayPlatform);
		}
		vspd = 0;
	} 
}