/// @description Insert description here
// You can write your code in this editor



if (tangible) collisionsX();
	
x += hspd;

if (tangible) collisionsY();
	
y+= vspd;