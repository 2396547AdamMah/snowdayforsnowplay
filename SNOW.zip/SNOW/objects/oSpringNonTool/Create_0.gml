/// @description Insert description here
// You can write your code in this editor
hspd = 0;
vspd = 0;

landed = false;


tilemap = layer_tilemap_get_id("Collision");

image_speed = 0;
