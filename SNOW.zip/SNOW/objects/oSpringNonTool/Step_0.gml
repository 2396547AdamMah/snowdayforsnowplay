/// @description Insert description here
// You can write your code in this editor
if (!instance_exists(owner)) {
	vspd += 0.15;
}

if (place_meeting(x,y+1,tilemap) || place_meeting(x,y+1,oWallNonPlayer)) {
	landed = true;
	//hspd *= 0.7;
	//vspd = -vspd*0.2;
} else landed = false;


if (place_meeting(x +hspd, y, tilemap)) {
	while (!place_meeting(x + sign(hspd),y,tilemap)) {
		x += sign(hspd)
	}
	//landed = true;
	hspd = -hspd*0.7;
}
x += hspd;

if (place_meeting(x , y + vspd, tilemap)) {
	while (!place_meeting(x ,y + sign(vspd),tilemap)) {
		y += sign(vspd)
	}
	//landed = true;
	if (vspd > 0) {
		hspd *= 0.7;
		vspd = -vspd*0.2;
	} else {
		vspd = 0;
	}
	
}
var _wall = instance_place(x,y+vspd,oWallNonPlayer);
if (_wall != noone && vspd >= 0) {
	var _sign = instance_place(x,y+sign(vspd),oWallNonPlayer);
	while (_sign == noone) {
		y += sign(vspd)
		_sign = instance_place(x,y+sign(vspd),oWallNonPlayer);
	}
	//landed = true;
	if (vspd > 0) {
		hspd *= 0.7;
		vspd = -vspd*0.2;
		if (owner != noone) {
			owner.holdingItem = noone;
			owner = noone;
		}
	} else {
		vspd = 0;
	}
	
}

y += vspd;