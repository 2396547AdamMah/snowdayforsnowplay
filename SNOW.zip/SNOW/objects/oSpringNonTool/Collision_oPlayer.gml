/// @description Insert description here
// You can write your code in this editor
if (landed && !instance_exists(owner) && !keyboard_check(vk_up)) {
	other.y = bbox_top - 8
	other.hspd = 0;
	other.vspd = -4.5;
	other.groundReset();
	image_speed = 1;
}
