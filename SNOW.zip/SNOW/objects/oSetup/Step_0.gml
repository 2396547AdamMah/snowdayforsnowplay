/// @description Insert description here
// You can write your code in this editor
switch (setupState) {
	case 0:
		instance_create_depth(0,0,-9999,ctrlGame)
		setupState++;	
		break;
	
	case 1:
		instance_create_depth(0,0,-9999,oCam)	
		setupState++;
		break;
	
	case 2: 
		ctrlGame.currentRoom = rmSubways;
		room_goto(rmSubways);
		instance_destroy();
		break;
}
