/// @description Insert description here
// You can write your code in this editor
event_inherited();
draw_circle(x,y,horizontalDetectRange,true);
draw_circle(x,y,groundDetectRange,true);
draw_circle(x,y,alreadyDetectedRange,true);