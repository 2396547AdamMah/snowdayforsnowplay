/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

image_xscale = -1.5;
image_yscale = 1.5;
grav = 0.15;

dir = 1;
target = noone;
aiming = new Vector2();

jumping = false;
jumpTimer = 0;
jumpDelay = 5;

groundDetectRange = 60;
horizontalDetectRange = 120;
alreadyDetectedRange = 200;

jumpSpeed = 3.5;
moveSpeed = 2;

moveSpeedMin = 3;
moveSpeedMax = 4;
moveSpeedAccel = (moveSpeedMax - moveSpeedMin)/4;

jumpHeightMin = 1.5;
jumpHeightMax = 3;

moveDecel = 0.2;
moveTurnSpeed = 0.1;

state = "IDLE"
previousDir = 0;
accSpeed = moveSpeed;

function decideJumpHeight(_target) {
	if (place_meeting(x + moveSpeedMax,y,tilemap)) {
		return jumpHeightMax;
	}
	if (_target != noone) {
		var _dist = y - _target.y;
		
		if (_dist > 24) {
			return jumpHeightMax/1.2;
		} else if (_dist > 12) {
			return jumpHeightMax/1.5;
		} 
	}
	return jumpHeightMin;
}