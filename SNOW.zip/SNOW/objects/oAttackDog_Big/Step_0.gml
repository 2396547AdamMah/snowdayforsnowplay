/// @description Insert description here
// You can write your code in this editor


if (target == noone) {
	target = collision_circle(x,y,horizontalDetectRange,oPlayer,false,true);
} else {
	target = collision_circle(x,y,alreadyDetectedRange,oPlayer,false,true);
}


switch (state) {
	case "IDLE":
		sprite_index = sDog_Idle;
		image_index = 0;
		image_speed = 0;
		hspd = lerp(hspd,0,moveDecel);
		
		if (target != noone) {
			if (y - target.y > groundDetectRange) {
				target = noone;
			} else {
				state = "DETECT"
			}
		}
		break;
	case "DETECT":
		if (target != noone) {
			if (y - target.y > groundDetectRange) {
				target = noone;
				state = "IDLE";
				break;
			} 
		} else {
			state = "IDLE";
		}
		if (target != noone) {
	
			aiming.set(target.x,target.y);
			var _dist = abs(x-aiming.x);
			var _dir = -sign(x - aiming.x);
			
			
			
			if (!jumping) {
				jumpTimer++;
				
				hspd = lerp(hspd,0,moveDecel);
				
				if (jumpTimer >= jumpDelay) {
					if (_dir == previousDir) {
						accSpeed += moveSpeedAccel;
					} else {
						previousDir = _dir;
						accSpeed = moveSpeedMin;
					}
					
					
					vspd = -decideJumpHeight(target);
					hspd = accSpeed*_dir;
					if (_dir != 0) image_xscale = _dir*abs(image_xscale);
					
					jumping = true;
					instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
					sprite_index = sDog_Run;
					image_index = 0;
					image_speed = 0;
				}
			} else {
				jumpTimer = 0;
				
				hspd = lerp(hspd,(moveSpeedMin*_dir)/2,0.05);
				if (_dir != 0) image_xscale = _dir*abs(image_xscale);;
				if (onGround()) {
					jumping = false;
					sprite_index = sDog_Run;
					image_index = 1;
					image_speed = 0;
					
				}
			}
			
		} 
		
		break;
}

if (abs(vspd) < 0.5) {
	vspd += grav/2;
}
else vspd += grav;

if (!jumping) {
	var _spear = instance_place(x + (image_xscale/1.5)*64,y,oSpear);
	
	if (_spear != noone && !_spear.recalling) {
		if (_spear.owner != noone) {
			target = _spear.owner;
			state = "DETECT";
		}
		vspd = -jumpHeightMax;
	}
}

// Inherit the parent event
event_inherited();