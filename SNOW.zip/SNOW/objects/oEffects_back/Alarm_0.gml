/// @description Insert description here
// You can write your code in this editor
//effect_create_depth(depth,ef_cloud,
	//irandom_range(0,room_width),
	//irandom_range(0,room_height),1,#6770B2)
alarm[0] = 20;