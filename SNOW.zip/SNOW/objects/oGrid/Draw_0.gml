/// @description Insert description here
// You can write your code in this editor
//shader_reset();
//mp_grid_draw(global.pathfindingGrid);
//shader_set(shd_colorReplace);


//draw_set_alpha(0.5);
//mp_grid_draw(global.backWallGrid);
//draw_set_alpha(1);
//if (ds_exists(global.pathfindingGrid,ds_type_grid)) {
	//for (var i = floor(oCam.camX/8); i <  floor((oCam.camX+320)/8); i++) {
		//for (var j = floor(oCam.camY/8); j < floor((oCam.camY+240)/8); j++) {
			//var _val = ds_grid_get(global.pathfindingGrid,i,j);
			//draw_text_transformed(i*cellWidth,j*cellWidth,string(_val),0.2,0.2,0);
		//}
	//}
//}
