/// @description Insert description here
// You can write your code in this editor
var _cellH = ceil(room_width/cellWidth);
var _cellV = ceil(room_height/cellWidth);
global.pathfindingGrid = mp_grid_create(0,0,room_width/8,room_height/8,8,8);

for (var i = 0; i < _cellH; i++) {
	for (var j = 0; j < _cellV; j++) {
		if (tilemap_get_at_pixel(tilemap,i*cellWidth,j*cellWidth) != 0) {
			//ds_grid_add(global.pathfindingGrid,i,j,-2)
			mp_grid_add_cell(global.pathfindingGrid,i,j);
			
		} 
		if (tilemap_get_at_pixel(tilemapBackWall,i*cellWidth,j*cellWidth) == 0) {
			//ds_grid_add(global.pathfindingGrid,i,j,-2)
			mp_grid_add_cell(global.backWallGrid,i,j);
			
		} 
		 //* /*else {
			//if (tilemap_get_at_pixel(tilemap,i*cellWidth,(j+1)*cellWidth) != 0) {
				//ds_grid_add(global.pathfindingGrid,i,j,0)
			//}
			//else 
			if (tilemap_get_at_pixel(tilemap,i*cellWidth,(j+2)*cellWidth) == 0) {
				var _oneWay = collision_rectangle(i*cellWidth,(j)*cellWidth,
					(i+1)*cellWidth,(j+2)*cellWidth,
					oOneWayPlatform,false,true);
				//var _poleV = collision_rectangle(i*cellWidth,(j)*cellWidth,
					//(i+1)*cellWidth,(j+2)*cellWidth,
					//oClimbablePole,false,true)
				if (_oneWay != noone) {
					mp_grid_add_cell(global.pathfindingGrid,i,j);
				}
				//ds_grid_add(global.pathfindingGrid,i,j,0)
				//ds_grid_add(global.pathfindingGrid,i,j,0)
				
			}
		//}*/
	}
}

//for (var i = 0; i < _cellH; i++) {
	//for (var j = 0; j < _cellV; j++) {
		//if (tilemap_get_at_pixel(tilemap,i*cellWidth,j*cellWidth) == 0) {
			//
			//ds_grid_add(global.pathfindingGrid,i,j,-1)
		//}
	//}
//}