/// @description Insert description here
// You can write your code in this editor
cellWidth = 8
tilemap = layer_tilemap_get_id("Collision");
tilemapBackWall = layer_tilemap_get_id("Tiles_4");

global.pathfindingGrid = mp_grid_create(0,0,room_width/8,room_height/8,8,8);
global.backWallGrid = mp_grid_create(0,0,room_width/8,room_height/8,8,8);