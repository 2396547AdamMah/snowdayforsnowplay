/// @description Insert description here
// You can write your code in this editor
time++;

vspd = 2* sin(0.03*time)

x += hspd;
y += vspd;