/// @description Insert description here
// You can write your code in this editor

function findClimbablePath(_target = new Vector2()) {
	var _dir = point_direction(x,y,_target.x,_target.y);
	var _dist = point_distance(x,y,_target.x,_target.y);
	var _climbables = [];
	var _nodes = []; //idk;
	
	
}