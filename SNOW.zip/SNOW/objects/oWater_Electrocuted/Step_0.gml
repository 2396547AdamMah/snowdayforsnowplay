/// @description Insert description here
// You can write your code in this editor
var _index = ds_list_find_index(inside,oPlayer);
if (place_meeting(x,y,oPlayer) && _index == -1) {
	ds_list_add(inside,oPlayer);
	instance_create_depth(oPlayer.x,bbox_top,oPlayer.depth-1,oFX,{sprite: sWaterSplash})
}

if (_index != -1 && !place_meeting(x,y,oPlayer)) {
	ds_list_delete(inside,_index);
	instance_create_depth(oPlayer.x,bbox_top,oPlayer.depth-1,oFX,{sprite: sWaterSplash})
}

raindropTimer++;
lightningTimer++;

if (raindropTimer >= raindropDelay) {
	var _x = irandom_range(bbox_left+4,bbox_right-4);
	instance_create_depth(_x,bbox_top,depth-1,oFX,{sprite: sWaterSplash})
	raindropTimer = 0;
}

if (lightningTimer >= lightningDelay) {
	var _x = irandom_range(bbox_left+4,bbox_right-4);
	instance_create_depth(_x,bbox_top+2,depth-1,oFX,{sprite: sWaterLightning})
	raindropTimer = 0;
}