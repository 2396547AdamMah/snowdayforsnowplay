/// @description Insert description here
// You can write your code in this editor


slope = (pos2.y - pos1.y) / (pos2.x - pos1.x)
yIntercept = -((pos1.x * slope) - pos1.y)

var _coll = collision_line(pos1.x,pos1.y, 
	pos2.x,pos2.y,
	oPlayer,false,false)

var _collWall = collision_line(pos1.x,pos1.y, 
	pos2.x,pos2.y,
	tilemap,false,false)

if (_collWall != noone) {
	instance_destroy();
	struct.javWire = noone;
}
if (abs(pos2.x - pos1.x) < 10) {
	instance_destroy();
	struct.javWire = noone;
}

if (_coll != noone) {
	oPlayer.wireTouching = id;
}