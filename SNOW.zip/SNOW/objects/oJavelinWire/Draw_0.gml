/// @description Insert description here
// You can write your code in this editor
//shader_reset();
draw_set_colour(image_blend);

draw_line_width(pos1.x,pos1.y,pos2.x,pos2.y,1);
//draw_sprite(sBunnyBall,0,pos1.x,pos1.y);
//draw_sprite(sBunnyBall,0,pos2.x,pos2.y);


draw_set_colour(c_white);
//shader_set(shd_colorReplace);