/// @description Insert description here
// You can write your code in this editor

slope = (pos2.y - pos1.y) / (pos2.x - pos1.x)
yIntercept = -((pos1.x * slope) - pos1.y)

function getY(_x) {
	return slope*_x + yIntercept;
}

show_debug_message($"{pos2.x}, {pos2.y}")
tilemap = layer_tilemap_get_id("Collision");
