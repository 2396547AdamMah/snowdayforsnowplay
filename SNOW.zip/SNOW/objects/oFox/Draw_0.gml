/// @description Insert description here
// You can write your code in this editor
event_inherited();
//draw_text(x,y,state);
//draw_text(x,y-16,jumpTimer);
//draw_circle(x,y,playerDetectRange,true);