/// @description Insert description here
// You can write your code in this editor
if (elevating) {
	x += lengthdir_x(elevateSpd,dir);
	y += lengthdir_y(elevateSpd,dir);
	
	
	oPlayer.x = x+16;
	oPlayer.y = bbox_top-8;
	
	
	
	persistent = true;
	
	var _stop = instance_place(x,y+elevateSpd,oElevatorStop);
	if (_stop != noone) {
		elevating = false;
		oPlayer.state = ePlayerState.FREE;
		dir = dir == 90 ? 270 : 90;
		//y = _stop.y;
	}
	var _roomTs = instance_place(x,y,oRoomTransition);
	if (_roomTs != noone) {
		ctrlGame.gotoRoom(_roomTs.dest,_roomTs.destX,_roomTs.destY,dir,id);
	}
	
} else {
	persistent = false;
	var _player = instance_place(x,y-1,oPlayer);
	if (_player != noone) {
		if ((dir == 90  && Input.kUpPressed) 
			|| dir == 270 && Input.kDownPressed) {
			_player.state = ePlayerState.ELEVATOR;
			_player.hspd = 0;
			_player.vspd = 0;
			startElevating(_player);
		}
		
	}
}