/// @description Insert description here
// You can write your code in this editor

elevating = false;
elevateSpd = 8/3;
//timeToElevate = 3*16;

timer = 0;
rider = noone;

function startElevating(_rider) {
	rider = _rider;
	elevating = true;
	timer = 0;	
}
currentRoom = room;