/// @description Insert description here
// You can write your code in this editor
oPlayer.heartPieces++;
instance_destroy();