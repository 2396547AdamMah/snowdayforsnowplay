/// @description Insert description here
// You can write your code in this editor
array_push(oPlayer.inventory, new ToolJavline());
instance_destroy();