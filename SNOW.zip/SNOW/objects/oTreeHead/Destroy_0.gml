/// @description Insert description here
// You can write your code in this editor
if (instance_exists(next)) {
	instance_destroy(next);
}