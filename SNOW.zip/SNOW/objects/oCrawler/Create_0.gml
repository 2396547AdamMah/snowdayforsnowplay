/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();

moveSpeed = 0.8;
grav = 0.15;
dir = 1;

moveTimer = 0;
moveDelay = 24;
moveTime = 32;
moving = false;

numberParts = 6;
next = noone;
//partScale = [1.3,1.3,1.15,1,0.9,0.8]
var _previous = id;
for (var i = 0; i < numberParts; i++) {
	//var _scale = partScale[i]
	var _next = instance_create_depth(x,y - i*6,depth+i,oCrawlerBody, {
		previous: _previous,
		head: id,
		//image_xscale: _scale,
		//image_yscale: _scale
	});
	_previous = _next;
	if (i == 0) {
		next = _next;
	}
}