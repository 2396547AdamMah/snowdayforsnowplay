/// @description Insert description here
// You can write your code in this editor


if (!place_meeting(x+dir*4,y+4,tilemap)) {
	dir = -dir;
	//vspd = -1;
	//if (instance_exists(next)) {
		//next.toPrevious(new Vector2(hspd,-6));
	//}
	//vspd = -1;
	
}
if (place_meeting(x+dir*4,y,tilemap)) {
	dir = -dir;
	//vspd = -1;
	//if (instance_exists(next)) {
		//next.toPrevious(new Vector2(hspd,-6));
	//}
	//vspd = -1;
	
}

if (moving) {
	hspd = lerp(hspd,moveSpeed*dir,0.2);
	vspd += grav;
	
	if (moveTimer > moveTime) {
		moving = false;
		moveTimer = 0;
	}
	
} else {
	hspd = lerp(hspd,0,0.2);
	vspd += grav;
	
	if (moveTimer > moveDelay) {
		moving = true;
		moveTimer = 0;
	}
}

moveTimer++;




// Inherit the parent event
event_inherited();
