/// @description Insert description here
// You can write your code in this editor
if (instance_exists(oCam.camZone)) {
	part_emitter_region(oParticles_Setup_back.partSystemBack,emitterSnowBack,
	oCam.camZone.bbox_left,oCam.camZone.bbox_right+100,
	oCam.camZone.bbox_top-40,oCam.camZone.bbox_bottom+40,
	ps_shape_rectangle,ps_distr_linear)
}