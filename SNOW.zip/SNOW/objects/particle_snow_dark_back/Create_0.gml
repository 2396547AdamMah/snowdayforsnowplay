/// @description Insert description here
// You can write your code in this editor

xStart = camera_get_view_x(view_camera[0])
yStart = camera_get_view_y(view_camera[0])

camWidth = camera_get_view_width(view_camera[0])
camHeight = camera_get_view_height(view_camera[0])


emitterSnowBack = part_emitter_create(oParticles_Setup_back.partSystemBack);
emitterRainBack = part_emitter_create(oParticles_Setup_back.partSystemBack);

//
part_emitter_region(oParticles_Setup_back.partSystemBack,emitterSnowBack,
	xStart+180,xStart+room_width+180,
	yStart-40,yStart+room_height+40,
	ps_shape_rectangle,ps_distr_linear)

part_emitter_stream(oParticles_Setup_back.partSystemBack,emitterSnowBack,
	oParticles_Setup_back.partSnowBackDark,2)

//part_emitter_region(oParticles_Setup_back.partSystemBack,emitterSnowBack,
	//xStart-20,xStart+room_width+20,
	//yStart-40,yStart+room_height+10,
	//ps_shape_rectangle,ps_distr_linear)
//
//part_emitter_stream(oParticles_Setup_back.partSystemBack,emitterSnowBack,
	//oParticles_Setup_back.partSnowSlow,2)

//part_emitter_region(oParticles_Setup_back.partSystemBack,emitterRainBack,
	//xStart,xStart+camWidth+100,
	//yStart-40,yStart+40,
	//ps_shape_rectangle,ps_distr_linear)
//
//part_emitter_stream(oParticles_Setup_back.partSystemBack,emitterRainBack,
	//oParticles_Setup_back.partRain,2)
