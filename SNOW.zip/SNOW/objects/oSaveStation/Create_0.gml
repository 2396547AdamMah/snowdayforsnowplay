/// @description Insert description here
// You can write your code in this editor
showArrow = false;
timer = 0;
arrow = noone;

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	//image_blend: other.image_blend,
	owner: id
})
sprite_index = sSaveStation;