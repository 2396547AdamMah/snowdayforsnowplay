/// @description Insert description here
// You can write your code in this editor
image_blend = ctrlGame.roomColor;

draw_sprite_ext(sprite_index,image_index,round(x),round(y),
	image_xscale,image_yscale,image_angle,image_blend,image_alpha);
//if (showArrow) {
	//draw_sprite(sSaveStationArrow_Info,timer,x+8,y-32);
	//timer++;
//}
