/// @description Insert description here
// You can write your code in this editor
if (place_meeting(x,y-1,oPlayer)) {
	image_index = 1;
	if (arrow == noone) {
		arrow = instance_create_depth(x+8,y-40,depth+1,oSaveArrow);
		
	}
	if (Input.kDownPressed) {
		oPlayer.state = ePlayerState.SAVE;
	}
} else {
	image_index = 0;
	instance_destroy(arrow)
	arrow = noone;
}
//
//x = round(x);
//y = round(y);
//var _visible = (collision_circle(x,y,128,oPlayer,false,false) != noone);
if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	glow.image_xscale = image_xscale;
	glow.image_yscale = image_yscale;
	//glow.visible = _visible;
	var _asset = $"{sprite_get_name(sprite_index)}_Glow";

	glow.sprite_index = asset_get_index(_asset);
}