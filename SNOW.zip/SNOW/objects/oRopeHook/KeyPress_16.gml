/// @description Insert description here
// You can write your code in this editor
//instance_create_depth(x+attachX,y+attachY,depth+1,oClimbablePole,{
		//image_yscale: 2
	//})