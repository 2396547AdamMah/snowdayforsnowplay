/// @description Insert description here
// You can write your code in this editor
draw_self();
draw_sprite(s_part_rain,0,attachX,attachY);