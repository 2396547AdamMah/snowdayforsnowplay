/// @description Insert description here
// You can write your code in this editor
hspd = 0;
vspd = 0;
image_index = 0;
attachX = lengthdir_x(sprite_width/2,image_angle)
attachY = lengthdir_y(sprite_height/2,image_angle)

recalling = false;
fumble = false;
landed = false;
rope = noone;


turnSpdMax = 20;
tilemap = layer_tilemap_get_id("Collision");


function recall() {
	landed = false;
	recalling = true;
	image_index = 1; 
	if (rope != noone) {
		instance_destroy(rope)
		rope = noone;
	}
}

function onLand() {
	rope = instance_create_depth(x+attachX,y+attachY+8 * 10,depth+1,oClimbablePole,{
		image_yscale: 10
	})
	
}

var _asset = $"{sprite_get_name(sprite_index)}_Glow";

glow = instance_create_depth(x,y,-9999,oGlow,{
	sprite_index: asset_get_index(_asset),
	image_blend: other.image_blend,
	owner: id
})