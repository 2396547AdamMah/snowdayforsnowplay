/// @description Insert description here
// You can write your code in this editor


attachX = lengthdir_x(-sprite_width/2,image_angle)
attachY = lengthdir_y(-sprite_height/2,image_angle)

if (landed) {
	hspd = 0;
	vspd = 0;
} else if recalling {
	var _dir = point_direction(x,y,owner.x,owner.y);
	var _dist = point_distance(x,y,owner.x,owner.y);
	var _spd = max(4,_dist/8)
	
	hspd = lengthdir_x(_spd,_dir)
	vspd = lengthdir_y(_spd,_dir)
	
	if (place_meeting(x,y,owner)) {
		owner.onRecall(id,fumble);
	}
	
	image_angle += turnSpdMax;
	//turnSpd = min(turnSpdMax,turnSpd+turnSpdAccel);
} else {
	
}
if (place_meeting(x+hspd,y,tilemap) && !recalling) {
		while (!place_meeting(x+sign(tilemap),y,oWall)) {
			x += sign(hspd)
		}
		if (!landed) {
			onLand();
			landed = true;
		}
		hspd = 0;
		
	}
x += hspd;

if (place_meeting(x,y+vspd,tilemap) && !recalling) {
	while (!place_meeting(x,y+sign(vspd),tilemap)) {
		y += sign(vspd)
	}
	if (!landed) {
		onLand();
		landed = true;
	}
	vspd = 0;
	
}
y += vspd;

x = round(x);
y = round(y);
if (instance_exists(glow)) {
	glow.x = x;
	glow.y = y;
	glow.image_index = image_index;
	glow.image_angle = image_angle;
	if (place_meeting(x,y,oPlayer)) {
		glow.visible = false;
	} else glow.visible = true;
}