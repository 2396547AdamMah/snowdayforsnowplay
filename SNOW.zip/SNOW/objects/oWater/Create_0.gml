/// @description Insert description here
// You can write your code in this editor
//image_alpha = 0.9;
beforeInside = ds_list_create();
inside = ds_list_create() 

raindropTimer = 0;
raindropDelay = 4;
