/// @description Insert description here
// You can write your code in this editor
event_inherited();
image_index = irandom(sprite_get_number(sprite_index));
pushFac = 0.8;
touching = false;