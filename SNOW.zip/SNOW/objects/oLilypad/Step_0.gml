/// @description Insert description here
// You can write your code in this editor
if (place_meeting(x,y,oWater)) {
	vspd = 0;
} 
if(place_meeting(x,y,oPlayer)) {
	if (!touching) {
		var _dir = -sign(oPlayer.x - x);
		hspd = (pushFac * max(1,abs(oPlayer.hspd))) * _dir;
		touching = true;
	}
	
} else touching = false;
	
hspd = lerp(hspd,0,0.1);

event_inherited();