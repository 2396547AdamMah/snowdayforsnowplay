/// @description Insert description here
// You can write your code in this editor

if (place_meeting(x,y,oWall)) {
	owner.setGrapplePoint(false,x,y)
	instance_destroy();
}
if (place_meeting(x,y + 1, oWall)) {
	owner.setGrapplePoint(true,x,y);
}