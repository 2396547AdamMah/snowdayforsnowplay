/// @description Insert description here
// You can write your code in this editor
array_push(oPlayer.inventory, new ToolRope());
instance_destroy();