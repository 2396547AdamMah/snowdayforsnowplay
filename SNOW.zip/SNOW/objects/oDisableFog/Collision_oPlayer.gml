/// @description Insert description here
// You can write your code in this editor
if (instance_exists(oSnowFog)) {
	if (oSnowFog.state != -4 || oSnowFog.state = 1) {
		oSnowFog.state = 1;
	}
}