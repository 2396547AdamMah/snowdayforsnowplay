/// @description Insert description here
// You can write your code in this editor

xStart = camera_get_view_x(view_camera[0])
yStart = camera_get_view_y(view_camera[0])

camWidth = camera_get_view_width(view_camera[0])
camHeight = camera_get_view_height(view_camera[0])

//emitterSnow = part_emitter_create(oParticles_Setup.partSystem);
//emitterSnowBack = part_emitter_create(oParticles_Setup.partSystem);
emitterRain = part_emitter_create(oParticles_Setup.partSystem);
//emitterSnowCloud = part_emitter_create(oParticles_Setup.partSystem);

//part_emitter_region(oParticles_Setup.partSystem,emitterSnow,
	//xStart,xStart+room_width+100,
	//yStart-40,yStart+room_height+40,
	//ps_shape_rectangle,ps_distr_linear)
//
part_emitter_stream(oParticles_Setup.partSystem,emitterRain,
	oParticles_Setup.partRain,1)

//part_emitter_region(oParticles_Setup.partSystem,emitterSnowBack,
	//xStart,xStart+camWidth+100,
	//yStart-40,yStart+camHeight+40,
	//ps_shape_rectangle,ps_distr_linear)
//
//part_emitter_stream(oParticles_Setup.partSystem,emitterSnowBack,
	//oParticles_Setup.partSnowBack,2)

//part_emitter_region(oParticles_Setup.partSystem,emitterRain,
	//xStart-20,xStart+camWidth+20,
	//yStart-40,yStart+20,
	//ps_shape_rectangle,ps_distr_linear)
//
//part_emitter_stream(oParticles_Setup.partSystem,emitterRain,
	//oParticles_Setup.partRain,3)