/// @description Insert description here
// You can write your code in this editor
for (var i = 0; i < array_length(webs); i++) {
	draw_path(webs[i],x,y,false);
}