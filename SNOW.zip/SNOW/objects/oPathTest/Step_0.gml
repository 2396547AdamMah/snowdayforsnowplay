/// @description Insert description here
// You can write your code in this editor
var length = point_distance(x, y, mouse_x, mouse_y);

var middle_x = (x + mouse_x) / 2;

// Set middle y to exact middle + weight of string
var middle_y = ((y + mouse_y) / 2) + (length / 4);

path_change_point(webs[0],1,middle_x,middle_y,100)
path_change_point(webs[0],2,mouse_x,mouse_y,100);
//if (mouse_check_button_pressed(mb_left)) {
	//// Start path
	//var new_web = path_add();
	//
	//// First anchor
	//path_add_point(new_web, x, y, 100);
//
	//// Get distance between both anchor points
	//var length = point_distance(x, y, mouse_x, mouse_y);
//
	//// Set middle x to exact middle
	//var middle_x = (x + mouse_x) / 2;
//
	//// Set middle y to exact middle + weight of string
	//var middle_y = ((y + mouse_y) / 2) + (length / 4);
//
	//// Add middle point
	//path_add_point(new_web, middle_x, middle_y, 100);
//
	//// Last anchor
	//path_add_point(new_web, mouse_x, mouse_y, 100);
//
	//// Ensure web is curved on bends
	//path_set_kind(new_web, 1);
	//path_change_point(web[0],2,mouse_x,mouse_y,100);
	//// Don't close path
	//path_set_closed(new_web, 0);
//
	//// Add new web to web array for drawing
	//array_push(webs, new_web);
//}