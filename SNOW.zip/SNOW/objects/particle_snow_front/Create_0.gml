/// @description Insert description here
// You can write your code in this editor

xStart = camera_get_view_x(view_camera[0])
yStart = camera_get_view_y(view_camera[0])

camWidth = camera_get_view_width(view_camera[0])
camHeight = camera_get_view_height(view_camera[0])

emitterSnowFront = part_emitter_create(oParticles_Setup.partSystem);

//emitterSnowCloud = part_emitter_create(oParticles_Setup.partSystem);

part_emitter_region(oParticles_Setup.partSystem,emitterSnowFront,
	xStart-20,xStart+camWidth+256,
	yStart-20,yStart+20,
	ps_shape_rectangle,ps_distr_linear)

part_emitter_stream(oParticles_Setup.partSystem,emitterSnowFront,
	oParticles_Setup.partSnowFront,1)