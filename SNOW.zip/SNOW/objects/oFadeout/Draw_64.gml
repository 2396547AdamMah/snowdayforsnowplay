/// @description Insert description here
// You can write your code in this editor
draw_set_alpha(image_alpha);
draw_set_colour(c_black);
draw_rectangle(0,0,room_width,room_height,false);
draw_set_alpha(1);
draw_set_colour(c_white);