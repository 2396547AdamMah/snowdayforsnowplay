/// @description Insert description here
// You can write your code in this editor
fadeOut = -1;
fadeSpeed = 1/5;
fadeDelay = 8;
fadeTimer = 0;
image_alpha = 0;