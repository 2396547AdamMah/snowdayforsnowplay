/// @description Insert description here
// You can write your code in this editor
//if (fadeOut == -2) {
	//fadeOut = -1;
//}