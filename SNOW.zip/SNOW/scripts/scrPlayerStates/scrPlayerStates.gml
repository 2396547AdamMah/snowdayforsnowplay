function playerStateFree(_self){ with (_self) {
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _kJump = keyboard_check_pressed(ord("Z"))
	var _kJumpReleased = keyboard_check_released(ord("Z"))
	var _kDown = keyboard_check(vk_down)
	var _kUp = keyboard_check(vk_up)
	var _kRun = keyboard_check(ord("J"))
	var _kRunPressed = keyboard_check_pressed(ord("J"))
	var _kGrab = Input.kGrab;
	
	var _kThrow = Input.kThrow;
	var _kRecall = Input.kRecall;
	var _input = _kRight - _kLeft;
	
	if (_input != 0) dir = _input;
		
	image_xscale = dir;
	//glowObj.image_xscale = dir;
	
	image_speed = 1;
	if (onGround()) {
		if (_input == 0) {
		
			
			if (isCrouched) {
				sprite_index = sBunnyCrouch;
			} else if (inWater && !place_meeting(x,y+1,tilemap)) {
				sprite_index = sBunnyCrouchRun;
			} else {
				sprite_index = sBunnyIdle;
				//glowObj.sprite_index = sBunnyGlow_Idle
			}
		} else {
			if (isCrouched) {
				sprite_index = sBunnyCrawl;
			}
			else {
				sprite_index = sBunnyCrouchRun;
			}
				//glowObj.sprite_index = sBunnyGlow_CrouchRun
		}
		
	} else {
		if isCrouched {
			sprite_index = sBunnyBall;
			//glowObj.sprite_index = sBunnyGlow_Ball
		} else {
			if (vspd < 0) {
				sprite_index = sBunnyJumpUp;
				//glowObj.sprite_index = sBunnyGlow_JumpUp
			
			}
			else {
				sprite_index = sBunnyJumpDown;
				//glowObj.sprite_index = sBunnyGlow_JumpDown
			}
		}
		
	}
	
	//if (_kDown && onGround()) {
		//state = ePlayerState.CRAWL;
		//isCrouched = true;
	//} else isCrouched = false;
		
	//if (onGround() && _input != 0 
	//&& collision_point(x+dir*4,y,tilemap,true,false) == noone 
	//&& place_meeting(x+dir,y-4,tilemap)) {
		//state = ePlayerState.CRAWL;
	//}
	#region Move
	
	
	if (onGround() || abs(hspd) - abs(moveSpd*_input) < 0) {
		if (isCrouched) {
			hspd = lerp(hspd,crouchSpd*_input,moveAccel);
		} else {
			var _spd = inWater ? waterMoveSpeed : moveSpd
			hspd = lerp(hspd,_spd*_input,moveAccel);
		}
		
	} else { //air moving
		
		hspd = lerp(hspd,moveSpd*_input,moveAccelAir);
	}
	#endregion	
	
	#region Jump
	if (jumpBuffer > 0 && coyotime > 0) {
		
		//vspd = _kDown && _input == 0 ? -jumpHeight*1.4 : -jumpHeight;
		vspd = -jumpHeight;
		instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
		jumpBuffer = 0;
		coyotime = 0;
	}
	
	if (!onGround() && jumpBuffer > 0 && ctrlGame.flags[eFlags.HAS_GLIDE] ) {
		vspd = 0.5
		state = ePlayerState.GLIDE;
	}
	
	//if (onWall() != 0 && _kJump && !onGround()) {
		//vspd = -jumpHeight;
		//hspd = -onWall() * wallJumpH;
		//instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
	//}
	if (_kJumpReleased && vspd < 0) {
		vspd /= 2;
	}
	
	#endregion
	var _water = instance_place(x,y-2,oWater);
	if (_water != noone ) {
		if (!inWater) {
			vspd *= waterEnterDecel;
			inWater = true;
		}
		
		image_speed = _input != 0 ? waterImageSpeedMoving : waterImageSpeedIdle;
		//if (abs(y - (_water.bbox_top-2)) < 2 && abs(vspd) < 0.1 ) {
			//vspd = lerp(vspd,0,0.1);
			//y = _water.bbox_top-2;
		//}
		//else 
		if (abs(vspd) < 0.04 && abs(y - (_water.bbox_top+2) < 1)) {
			vspd = lerp(vspd,0,0.1);
			//y = _water.bbox_top-2;
		}
		else {
			vspd -= 0.16;
		}
		if (place_meeting(x,y+1,tilemap)) {
			vspd *= 0.9;
		}
	} else {
		if (inWater) {
			vspd *= waterLeaveDecel;
			inWater = false;
		}
		
		vspd += grav;
	}
	
	
	
	
	
	if (onGround()) {
		airJumpsLeft = airJumpsMax;
		glideLiftTimer = 0;
		for (var i = 0; i < array_length(inventory); i++) {
			if (inventory[i].name = "GLIDE") {
				inventory[i].spent = false;
			}
		}
		lastSafeGround.x = x;
		lastSafeGround.y = y;
		
	}
	//if (onWall() == 0 || vspd < 0) {
	
	//} 
	
	#region Spears
	//ThrowSpear()
	
	//ThrowJavelin()
	//RecallSpear()
	//
	//Swing()
	#endregion
	
	//if (collision_point(x+_input*4,bbox_top,tilemap,true,false) != noone 
	//&& collision_point(x+_input*6,bbox_top-2,tilemap,true,false) == noone
	//&& !onGround() && edgeBuffer <= 0) {
		//state = ePlayerState.EDGE_HANG;
		//show_debug_message("HI")
		//hspd = 0;
		//vspd = 0;
	//}
	
	if (_kRunPressed) {
		hspd = dir * crouchDashSpeed;
		vspd = 0;
		instance_create_depth(x,y,depth+1,oFX,{sprite:s_fx_dustCloud})
	}
	#region Grabbing
	
	
	var _held = instance_place(x,y,oSpringNonTool);
	if (_held && _kUp) {
		_held.x = x
		_held.y = y-10;
		holdingItem = _held;
		//instance_destroy(_held)
		
	}
	
	if (!inWater) checkEnterCrawl();
	
	if (instance_exists(holdingItem)) {
		
		holdingItem.x = x
		holdingItem.y = y-10;
		//holdingItem.hspd = hspd;
		//var _vspd = onGround() ? vspd - grav : vspd;
		//holdingItem.vspd = _vspd;
		//instance_destroy(holdingItem)
		holdingItem.owner = id;
		if (_kThrow) {
			if (_kUp) {
				holdingItem.hspd = 0;
				holdingItem.vspd = -5;
			} else if (_kDown){
				if (onGround()) {
					holdingItem.hspd = dir*1.5;
					holdingItem.vspd = 2;
				} else {
					holdingItem.hspd = 0/*hspd*1.2*/;
					holdingItem.vspd = 4;
				}
				
			} else {
				holdingItem.hspd = dir*3.2;
				holdingItem.vspd = -1;
			}
			
			holdingItem.owner = noone;
			holdingItem = noone;
		}
		if (holdingItem != noone && y - holdingItem.y > 32) {
			holdingItem.owner = noone;
			holdingItem = noone;
		}
	} else {
		var _climbable = instance_place(x,y,oClimbable) 
		if (_climbable != noone && _kGrab && climbJumpBuffer == 0) {
			y = _climbable.y + 4;
			//glowObj.y = y;
			state = ePlayerState.CLIMB
			climbingOn = _climbable;
			hspd = 0;
			vspd = 0;
		}
		var _spear = instance_place(x,y,oSpear) 
		if (_spear != noone && _spear.landed && _kGrab && climbJumpBuffer == 0) {
			y = _spear.y + 4;
			//glowObj.y = y;
			state = ePlayerState.CLIMB
			climbingOn = _spear;
			hspd = 0;
			vspd = 0;
			fakeHspd = 0;
		}
		//var _jav = instance_place(x,y,oJavelin) 
		//if (_jav != noone && _jav.landed && _kGrab && climbJumpBuffer == 0) {
			//x = _jav.x;
			////glowObj.y = y;
			//state = ePlayerState.CLIMB_WALL
			//climbingOn = _jav;
			//hspd = 0;
			//vspd = 0;
		//}
		_climbable = instance_place(x,y+1,oClimbablePole)
		if (_climbable != noone && (_kGrab || keyboard_check_pressed(vk_down)) && climbJumpBuffer == 0) {
			x = _climbable.x;
			if (keyboard_check_pressed(vk_down) && !place_meeting(x,y+4,tilemap)) {
				y += 4;
			} else {
				y +=1;
			}
			//glowObj.x = x;
			state = ePlayerState.CLIMB_WALL
			climbingOn = _climbable;
			hspd = 0;
			vspd = 0;
			fakeVspd = 0;
		}
		_climbable = instance_place(x,y,oRingHold)
		if (_climbable != noone && _kGrab && climbJumpBuffer == 0) {
			x = _climbable.x;
			//glowObj.x = x;
			y = _climbable.y + 4;
			//glowObj.y = y;
			state = ePlayerState.HOLD_RING;
			climbingOn = _climbable;
			hspd = 0;
			vspd = 0;
		}
		if (instance_exists(wireTouching) && _kGrab && climbJumpBuffer <= 0) {
			javWire = wireTouching;
			hspd = 0;
			vspd = 0;
			y = javWire.getY(x);
			state = ePlayerState.CLIMB_WIRE;
		}
		//var _crawl = instance_place(x,y+1,oTunnelEntrance)
		//if (_kDown && _crawl != noone) {
			//state = ePlayerState.CRAWL;
			//x  = _crawl.x + 4;
			//y = _crawl.y + 12
		//}
	}
	#endregion
	//if (javWireSet && _kGrab && climbJumpBuffer == 0) {
		//var _wire = collision_line(javLine1.attachX,javLine1.attachY,
			//javLine2.attachX,javLine2.attachY,
			//id,false,false)
		//if (_wire != noone) {
			//var _slope = (javLine2.attachY - javLine1.attachY)/(javLine2.attachX - javLine1.attachX)
			//var _yInt = -((javLine1.attachX * _slope) - javLine1.attachY);
			//
			//y = _slope * x + _yInt;
			//hspd = 0;
			//vspd = 0;
			//state = ePlayerState.CLIMB_WIRE;
		//}
	//}
	//if (onWall() != 0 && _kGrab) {
		//hspd = 0;
		//vspd = 0;
		//climbingOn = getWallTouching();
		//state = ePlayerState.CLIMB_WALL;
	//}
}}
function playerStateEdgeHang(_self) { with (_self) {
	
	sprite_index = sBunnyEdgeHang;
	if (jumpBuffer > 0) {
		executeJump(,true);
	}
	if (Input.kDownPressed) {
		state = ePlayerState.FREE;
		edgeBuffer = 3;
		//y += 2
	}
	
	var _ny = 0;
	if (Input.kUpPressed) {
		while (collision_point(x+dir*10,y-_ny,tilemap,true,false) != noone) {
			_ny++;
		}
		y -= _ny +8;
		x += 4*dir;
		state = ePlayerState.FREE;
	}
	//var _target = new Vector2();
	//if (Input.kUp && _target.dir() == 0) {
		//while (collision_point(x+dir*6,y-_ny,tilemap,true,false) != noone) {
			//_ny++;
		//}
		//_target.y = y - (_ny +8);
		//_target.x = x + 4*dir;
	//}
	//
	//if (_target.dir() != 0) {
		//x = lerp(x,_target.x,0.2);
		//y = lerp(y,_target.y,0.2);
			//
		//if (x == _target.x && y == _target.y) {
			//state = ePlayerState.FREE;
		//}
	//}
}}
function playerStateCrawl(_self) { with (_self) {
	isCrouched = true;
	
	var _input = Input.kRight - Input.kLeft;
	var _inputV = Input.kDown- Input.kUp;
	
	//vspd += grav;
	var _exit = place_meeting(x,y,oCrawlExit);
	
	checkExitCrawl();
	sprite_index = sBunnyBall;
	image_speed = _input != 0 || _inputV != 0 ? 1 : 0
	//if (!_exit && (_inputV < 0 && !collision_point(x,y-8,tilemap,true,false)) ||
		//(_inputV > 0 && !collision_point(x,y+16,tilemap,true,false)) ) {
		//sprite_index = sBunnyCrawlV;
	//}
	//else if (_input != 0) {
		//dir = _input;
		//image_xscale = _input;
		//
		//sprite_index = sBunnyCrawl;
	//} else {
		//sprite_index = sBunnyCrouch;
	//}
	
	hspd = lerp(hspd,crawlSpeed * _input,moveAccel);
	if (!_exit) {
		vspd = lerp(vspd,crawlSpeed * _inputV,moveAccel);
	} else {
		vspd += grav;
	}
	
	//if (!Input.kDown && !solidAboveYou()) {
		//state = ePlayerState.FREE;
	//}
	//if (!onGround()) {
		//state = ePlayerState.FREE;
		//edgeBuffer = PLAYER_BUFFER
		////y += 6;
	//}
	//if (jumpBuffer > 0) {
		//vspd = -jumpHeight;
		//instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
		//jumpBuffer = 0;
		//coyotime = 0;
		//state = ePlayerState.FREE;
		//
	//}
	
}}

function playerStateClimbHang(_self) { with (_self) {
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _kJump = keyboard_check_pressed(ord("Z"))
	var _kDownPressed = keyboard_check_pressed(vk_down)
	var _kDown = keyboard_check(vk_down);
	var _kUpPressed = keyboard_check_pressed(vk_up)
	//var _kRun = keyboard_check(ord("C"))
	//var _kRunPressed = keyboard_check_pressed(ord("C"))
	var _input = _kRight - _kLeft;
	
	if (_input != 0) {
		dir = _input;
		image_xscale = _input;	
	}
		
	if (!instance_exists(climbingOn)) {
		show_debug_message("Object climbing on doesnt exist for some reason ._.")
		state = ePlayerState.FREE
		break;
	}
	
	if (!place_meeting(x,y,climbingOn) 
	&& (climbingOn.hspd != 0 || climbingOn.vspd != 0 ) ) {
		state = ePlayerState.FREE
		climbingOn = noone;
		fakeHspd = 0;
		break;
	}
	
	sprite_index = sBunnyHang;
	//glowObj.sprite_index = sBunnyGlow_Hang
	if (_input != 0) {
		image_speed = 1;
		
		
	} else image_speed = 0;
	
	//glideLiftTimer = 0;
	
	var _speed = climbSpeedH
	if (_kRight) {
		
		fakeHspd = lerp(fakeHspd,_speed,climbAccel);
		if (x + fakeHspd > climbingOn.bbox_right) {
			fakeHspd = 0;
		}
	}
	else if (_kLeft) {
		fakeHspd = lerp(fakeHspd,-_speed,climbAccel);
		if (x + fakeHspd < climbingOn.bbox_left) {
				fakeHspd = 0;
		}
	}
	else fakeHspd = lerp(fakeHspd,0,climbAccel);

	//show_debug_message($"{fakeHspd} : {_speed}")
	
	hspd = climbingOn.hspd + fakeHspd;
	vspd = climbingOn.vspd;
	
	
		var _climbable = instance_place(x,y,oClimbablePole)
		if (_climbable != noone && (_kUpPressed || _kDownPressed)) {
			x = _climbable.x;
			//glowObj.x = x;
			state = ePlayerState.CLIMB_WALL
			climbingOn = _climbable;
			hspd = 0;
			vspd = 0;
			fakeVspd = 0;
		}
		if (_kDown && jumpBuffer > 0) {
			state = ePlayerState.FREE;
			climbJumpBuffer = climbJumpBufferMaxDown
			climbingOn = noone;
			fakeHspd = 0;
			groundReset();
			jumpBuffer = 0;
		}
		if (jumpBuffer > 0) {
			
			vspd = -jumpHeight;
			instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
			state = ePlayerState.FREE;
			climbJumpBuffer = climbJumpBufferMax
			climbingOn = noone;
			fakeHspd = 0;
			jumpBuffer = 0;
			
			groundReset();
		}
		
		//if (_kDownPressed && !instance_exists(_climbable) ) {
			//state = ePlayerState.FREE;
			//climbJumpBuffer = climbJumpBufferMaxDown
			//climbingOn = noone;
			//fakeHspd = 0;
			//groundReset();
			//
		//}
	//
}
	
}

function playerStateWalkPole(_self) { with (_self) {
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _kJump = keyboard_check_pressed(ord("Z"))
	var _kDownPressed = keyboard_check_pressed(vk_down)
	var _kUpPressed = keyboard_check_pressed(vk_up)
	//var _kRun = keyboard_check(ord("C"))
	//var _kRunPressed = keyboard_check_pressed(ord("C"))
	var _input = _kRight - _kLeft;
	
	if (_input != 0) dir = _input;
		
	if (!instance_exists(climbingOn)) {
		show_debug_message("Object climbing on doesnt exist for some reason ._.")
		state = ePlayerState.FREE
		break;
	}
	
	if (!place_meeting(x,y+1,climbingOn)) {
		state = ePlayerState.FREE
		climbingOn = noone;
		fakeHspd = 0;
		break;
	}
	
	image_speed = 1;
	image_xscale = dir;
	if (_input == 0) {
		if (isCrouched) {
			sprite_index = sBunnyCrouch;
		} else {
			sprite_index = sBunnyIdle;
		}
	} else {
		sprite_index = sBunnyCrouchRun;
	}
	
	
	var _speed = moveSpd
	if (_kRight) {
		
		fakeHspd = lerp(fakeHspd,_speed,moveAccel);
		//if (x + fakeHspd > climbingOn.bbox_right) {
			//fakeHspd = 0;
		//}
	}
	else if (_kLeft) {
		fakeHspd = lerp(fakeHspd,-_speed,moveAccel);
		//if (x + fakeHspd < climbingOn.bbox_left) {
				//fakeHspd = 0;
		//}
	}
	else fakeHspd = lerp(fakeHspd,0,moveAccel);

	//show_debug_message($"{fakeHspd} : {_speed}")
	
	hspd = climbingOn.hspd + fakeHspd;
	vspd = climbingOn.vspd;
		
	coyotime = PLAYER_BUFFER;
	for (var i = 0; i < array_length(inventory); i++) {
		if (inventory[i].name = "GLIDE") {
			inventory[i].spent = false;
		}
	}
	
	
	if (jumpBuffer > 0) {
		vspd = -jumpHeight;
		jumpBuffer = 0;
		instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
		state = ePlayerState.FREE;
		climbJumpBuffer = climbJumpBufferMax;
		climbingOn = noone;
		fakeHspd = 0;
		groundReset();
	}
}}

function playerStateClimbWall(_self) { with (_self) {
	oneWayTangible = false;
	
	if (!instance_exists(climbingOn)) {
		state =ePlayerState.FREE;
		climbingOn = noone;
		fakeVspd = 0;
		break;
	}
	
	if (!place_meeting(x,y,climbingOn)) {
		state =ePlayerState.FREE;
		climbingOn = noone;
		fakeVspd = 0;
		break;
	}
	
	
	var _kDown = keyboard_check(vk_down)
	var _kUp = keyboard_check(vk_up)
	var _kJump = keyboard_check_pressed(ord("Z"))
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _kRightPressed = keyboard_check_pressed(vk_right)
	var _kLeftPressed = keyboard_check_pressed(vk_left)
	//var _kGrab = keyboard_check(ord("C"))
	
	var _input = _kDown - _kUp;
	var _inputH = _kRight - _kLeft;
	if (_inputH != 0) dir = _inputH;
	sprite_index = sBunnyHang;
	//glowObj.sprite_index = sBunnyGlow_Hang
	if (_input != 0) {
		image_speed = 1;
	} else image_speed = 0;
		
	var _speed = climbSpeedV;
	if (_kDown) {
		
		fakeVspd = lerp(fakeVspd,_speed,climbAccel);
		if (y + fakeVspd > climbingOn.bbox_bottom) {
			fakeVspd = 0;
		}
	}
	else if (_kUp) {
		fakeVspd = lerp(fakeVspd,-_speed,climbAccel);
		if (y + fakeVspd < climbingOn.bbox_top) {
				fakeVspd = 0;
		}
	}
	else fakeVspd = lerp(fakeVspd,0,climbAccel);
		
	hspd = climbingOn.hspd;
	vspd = climbingOn.vspd + fakeVspd;
	
	var _climbable = instance_place(x,y,oClimbable) 
	if (_climbable != noone && (_kRightPressed || _kLeftPressed)) {
		y = _climbable.y + 4; ;
		state = ePlayerState.CLIMB
		climbingOn = _climbable;
		hspd = 0;
		vspd = 0;
		fakeHspd = 0;
	}
	var _spear = instance_place(x,y,oSpear) 
	if (_spear != noone && _spear.landed && (_kRightPressed || _kLeftPressed)) {
		y = _spear.y + 4;
		//glowObj.y = y;
		state = ePlayerState.CLIMB
		climbingOn = _spear;
		hspd = 0;
		vspd = 0;
		fakeHspd = 0;
	}
	//if (wireTouching != noone && (_kRightPressed || _kLeftPressed)) {
	if (wireTouching != noone && (_kRight || _kLeft)) {
		javWire = wireTouching;
		hspd = 0;
		vspd = 0;
		y = javWire.getY(x);
		state = ePlayerState.CLIMB_WIRE;
	}
	
	
	if (jumpBuffer > 0) {
		if (_kDown) {
			state = ePlayerState.FREE;
			climbJumpBuffer = climbJumpBufferMaxDown
			climbingOn = noone;
			fakeVspd = 0;
		} else {
			if (_inputH != 0 || y - 8 < climbingOn.bbox_top) {	
				vspd = -jumpHeight;
				hspd = _inputH * 1.5;
				instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
				state = ePlayerState.FREE;
				climbJumpBuffer = climbJumpBufferMax
				climbingOn = noone; 
				fakeVspd = 0;
				jumpBuffer = 0;
				groundReset();
			} else {
				vspd = -jumpHeight;
				groundReset();
				jumpBuffer = 0;
				instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
			}
		}
		
	}
	
	
}}

function playerStateHoldRing(_self) { with (_self) { 
	var _kDownPressed = keyboard_check_pressed(vk_down)
	var _kUp = keyboard_check(vk_up)
	var _kJump = keyboard_check_pressed(ord("Z"))
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _input = _kRight - _kLeft;
	
	if (_input != 0) dir = _input
		
	hspd = climbingOn.hspd;
	vspd = climbingOn.vspd;
	
	sprite_index = sBunnyHang;
	image_speed = 0;
	
	//ThrowSpear()
	//RecallSpear()
	
	
	if (climbingOn == noone) {
		state = ePlayerState.FREE;
		climbJumpBuffer = climbJumpBufferMax
		climbingOn = noone;
	}
	
	//if (place_meeting(x,y,tilemap)) {
		//state = ePlayerState.FREE;
		//climbJumpBuffer = climbJumpBufferMax
		//climbingOn = noone;
	//}
	
	if (jumpBuffer > 0) {

		vspd = -jumpHeight;
		hspd = _input*2
		instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
		state = ePlayerState.FREE;
		climbJumpBuffer = climbJumpBufferMax
		climbingOn = noone;
		jumpBuffer = 0;
		groundReset();

	}
	
	if (_kDownPressed) {
		state = ePlayerState.FREE;
		climbJumpBuffer = climbJumpBufferMaxDown
		climbingOn = noone;
		groundReset();
		
	}
}}

function playerStateSwing(_self) { with (_self) { 
	var _kDown = keyboard_check(vk_down)
	var _kUp = keyboard_check(vk_up)
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _kJump = keyboard_check_pressed(ord("Z"))
	
	var _ropeAngleAccel = -0.2 * dcos(ropeAngle);
	_ropeAngleAccel += (_kRight - _kLeft) * 0.06;
	
	sprite_index = sBunnyBall
	
	ropeLength += (_kDown - _kUp) * 2;
	ropeLength = clamp(ropeLength,16,64);
	
	ropeAngleVelocity += _ropeAngleAccel;
	ropeAngle += ropeAngleVelocity;
	ropeAngleVelocity *= 0.99;
	
	ropeX = grappleX + lengthdir_x(ropeLength,ropeAngle);
	ropeY = grappleY + lengthdir_y(ropeLength,ropeAngle);
	
	hspd = ropeX - x;
	vspd = ropeY - y;
	
	//ThrowSpear();
	//RecallSpear();
	
	if (jumpBuffer > 0) {

		vspd = -jumpHeight;
		jumpBuffer = 0;
		instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
		state = ePlayerState.FREE;

	}
	
	//hspd = 0;
	//vspd = 0;
}}

function playerStateClimbWire(_self) {with (_self)  {
	
	oneWayTangible = false;
	
	if (!instance_exists(javWire)) {
		state = ePlayerState.FREE;
		javWire = noone
		break;
	}
	
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _input = _kRight - _kLeft;
	var _kDownPressed = keyboard_check_pressed(vk_down)
	var _kUp = keyboard_check(vk_up)
	var _kJump = keyboard_check_pressed(ord("Z"))
	
	var p1 = javWire.pos1; // [javLine1.attachX,javLine1.attachY]
	var p2 = javWire.pos2; //[javLine2.attachX,javLine2.attachY]
	//var _slope = (javLine2.attachY - javLine1.attachY)/(javLine2.attachX - javLine1.attachX)
	//var _yInt = -(javLine1.attachX * _slope - javLine1.attachY);
	
	if (_input != 0) dir = _input
	
	sprite_index = sBunnyHang;
	if (_input != 0) {
		image_speed = 1;
	} else image_speed = 0;
	
	hspd = lerp(hspd,_input*climbSpeedH,climbAccel);
	var _ny = javWire.getY(x+hspd);
	vspd = lengthdir_y(point_distance(x,y,x+hspd,_ny),point_direction(x,y,x+hspd,_ny));
	
	
	if (p1.x > p2.x) {
		x = clamp(x, p2.x,p1.x);
	
	} else {
		x = clamp(x, p1.x,p2.x);
	
	}
	
	if (_kJump) {
		vspd = -jumpHeight;
		jumpBuffer = 0;
		instance_create_depth(x,bbox_bottom-2,depth+1,oFX,{sprite:s_fx_dustCloud})
		state = ePlayerState.FREE;
		groundReset();
		climbJumpBuffer = climbJumpBufferMax
		climbingOn = noone;
	}
	
	if (_kDownPressed) {
		state = ePlayerState.FREE;
		groundReset();
		climbJumpBuffer = climbJumpBufferMaxDown
		climbingOn = noone;
		
	}
}}

function playerStateGlide(_self) { with (_self)  {
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _input = _kRight - _kLeft;
	var _kDownPressed = keyboard_check_pressed(vk_down)
	var _kDown = keyboard_check(vk_down)
	var _kUp = keyboard_check(vk_up)
	var _kJump = keyboard_check_pressed(ord("Z"))
	var _kJumpReleased = keyboard_check_released(ord("Z"))
	
	if (_input != 0) dir = _input;
	
	image_xscale = dir;
	
	glideLiftTimer++;
	
	if (glideLiftTimer <= glideLiftDuration) {
		vspd -= glideLiftSpeed;
	} else {
		var _spd = glideSpeedV
		if (vspd < _spd) {
			vspd = min (vspd + glideAccelV, _spd);
		} else if (vspd > _spd) {
			vspd = min (vspd - glideAccelV, _spd)
		}
		
		//vspd = lerp(vspd,glideSpeedV,glideAccelV);
		if (onGround()) {
			state = ePlayerState.FREE
		}
	}
	
	hspd = lerp(hspd,_input*glideSpeedH,glideAccelH) //wind- 0.15
	
	
	
	//if (_kJump) {
		//
		//state = ePlayerState.FREE;
	//}
	//
	if (_kJumpReleased) {
		state = ePlayerState.FREE;
	}
	
	//if (_kDownPressed) {
		//state = ePlayerState.FREE;
	//}
	
	var _isGrabbing = Grab();
	
	
	//TODO: generic function for grabbing stuff
	//Cancel glide if grab something
	
}}
function playerStateSave(_self){ with (_self) {
	hspd = 0;
	vspd = 0;
	
	ctrlGame.saveGame();
	state = ePlayerState.FREE;
}}

function playerStateNoclip(_self) { with (_self) {
	var _kRight = keyboard_check(vk_right)
	var _kLeft = keyboard_check(vk_left)
	var _kJump = keyboard_check_pressed(ord("Z"))
	var _kJumpReleased = keyboard_check_released(ord("Z"))
	var _kDown = keyboard_check(vk_down)
	var _kUp = keyboard_check(vk_up)
	var _kRun = keyboard_check(ord("J"))
	var _kRunPressed = keyboard_check_pressed(ord("J"))
	var _kGrab = keyboard_check(vk_up)
	
	var _kThrow = keyboard_check_pressed(ord("X"));
	var _kRecall = Input.kRecall;
	var _input = _kRight - _kLeft;
	
	var _spd = 5;
	hspd = _input * _spd;
	vspd = (_kDown - _kUp) * _spd;
}}
