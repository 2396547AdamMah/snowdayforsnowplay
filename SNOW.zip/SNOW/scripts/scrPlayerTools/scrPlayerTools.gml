function Tool(_name) constructor {
	icon = sTool_Javline;
	name = _name;
	spent = false;
	
	static recall = function(_owner) {}
	
	static shoot = function(_owner,_vel,_blend = c_white) {}
}

function ToolFrisbee() : Tool("FRISBEE") constructor {
	icon = sTool_Frisbee;
	tool = noone;
	spent = false;
	
	static recall = function(_owner) {
		if (tool != noone) {
			tool.recall(_owner);
			tool = noone;
			spent = false;
		} else return -1;	
	}
	
	static shoot = function(_owner,_vel,_blend = c_white) {
		var _yOff = _owner.isCrouched ? 4 : 0
		var _self = self; // idk why, but self and other.self dont work down there
		if (tool == noone) {
			tool = instance_create_depth(_owner.x + sign(_vel.x)*12,_owner.y + _yOff,_owner.depth+1,oFrisbee, {
				owner: _owner,
				struct: _self,
				image_blend: _blend
			})
			with (tool) {
				//hspd = _vel.x;
				vspd = _vel.y;
				dir = sign(_vel.x);
			}
			spent = true;
		} else return -1;
	}
}
function ToolSpear() : Tool("SPEAR") constructor {
	icon = sTool_Spear;
	spear = noone;
	spent = false;
	
	static recall = function(_owner) {
		if (spear != noone) {
			spear.recall(_owner);
			spear = noone;
			spent = false;
		} else return -1;	
	}
	
	static shoot = function(_owner,_vel,_blend = c_white) {
		var _yOff = _owner.isCrouched ? 4 : 0
		var _self = self; // idk why, but self and other.self dont work down there
		if (spear == noone) {
			spear = instance_create_depth(_owner.x,_owner.y - 5 + _yOff,_owner.depth+1,oSpear, {
				owner: _owner,
				struct: _self,
				image_blend: _blend
			})
			with (spear) {
				hspd = _vel.x;
				vspd = _vel.y;
			}
			spent = true;
		} else return -1;
	}
}

function ToolJavline() : Tool("JAVLINE") constructor {
	
	icon = sTool_Javline;
	
	jav1 = noone;
	jav2 = noone;
	javWire = noone;
	javLineReady = false;
	javelinsLeft = 2;
	spent = false;
	blend = c_white;
	static recall = function(_owner) {
		javLineReady = false;
		
		if (javWire != noone) {
			instance_destroy(javWire)
			javWire = noone;
		}
		
		if (jav1 != noone) {
			jav1.recall(_owner,self);
			jav1 = noone;
			icon = sTool_Javline;
			spent = false;
		}
		 
		if (jav2 != noone) {
			jav2.recall(_owner,self);
			jav2 = noone;
			icon = sTool_Javline;
			spent = false;
		}
	}
	
	static onLanded = function(_jav) {
		
		if (jav1 != noone && jav2 != noone) {
			if (jav1.landed && jav2.landed) {
				
				if (!javLineReady) {
					javLineReady = true;
					show_debug_message($"B>{jav2.attachX}, {jav2.attachY}")
					setupWire();
				} else if (javWire != noone) {
					javWire.pos1 = new Vector2(jav1.attachX,jav1.attachY)
					javWire.pos2 = new Vector2(jav2.attachX,jav2.attachY)
				}
				
			}
		}
		
	}
	
	static setupWire = function() {
		var _self = self;
		show_debug_message($"C>{jav2.attachX}, {jav2.attachY}")
		javWire = instance_create_depth(0,0,jav1.depth-1,oJavelinWire,{
			pos1: new Vector2(jav1.attachX,jav1.attachY),
			pos2: new Vector2(jav2.attachX,jav2.attachY),
			image_blend: _self.blend,
			struct: _self
		})
	}
	
	static shoot = function(_owner,_vel,_blend = c_white) {
		var _self = self;
		blend = _blend;
		if (jav1 == noone) {
			jav1 = instance_create_depth(_owner.x,_owner.y,_owner.depth+1,oJavelin, {
				owner:_owner, 
				struct: _self,
				image_blend: _blend
				})
			with (jav1) {
				hspd = _vel.x;
				vspd = _vel.y;
			}
			icon = sTool_Javline_half;
		} 
		else if (jav2 == noone) {
			jav2 = instance_create_depth(_owner.x,_owner.y,_owner.depth+1,oJavelin, {
				owner:_owner, 
				struct: _self,
				image_blend: _blend
				})
			with (jav2) {
				hspd = _vel.x;
				vspd = _vel.y;
			}
			spent = true;
			
		}
		
		else return -1;
	}
}

function ToolRope() : Tool("ROPE") constructor {
	icon = sTool_Rope;
	rope = noone;
	spent = false;
	
	static recall = function(_owner) {
		if (rope != noone) {
			rope.recall(_owner);
			rope = noone;
			spent = false;
		} else return -1;	
	}
	
	static shoot = function(_owner,_vel,_blend = c_white) {
		var _self = self; // idk why, but self and other.self dont work down there
		if (rope == noone) {
			rope = instance_create_depth(_owner.x,_owner.y,_owner.depth+1,oRopeHook, {
				owner: _owner,
				struct: _self,
				image_angle: _vel.dir(),
				image_blend: _blend
			})
			with (rope) {
				hspd = _vel.x;
				vspd = _vel.y;
				
			}
			spent = true;
		} else return -1;
	}
}

function ToolSpring() : Tool("SPRING") constructor {
	icon = sTool_Spring;
	spring = noone;
	spent = false;
	
	static recall = function(_owner) {
		if (spring != noone) {
			spring.recall(_owner);
			spring = noone;
			spent = false;
		} else return -1;	
	}
	
	static shoot = function(_owner,_vel,_blend = c_white) {
		var _self = self; // idk why, but self and other.self dont work down there
		if (spring == noone) {
			spring = instance_create_depth(_owner.x,_owner.y,_owner.depth+1,oSpring, {
				owner: _owner,
				struct: _self,
				image_blend: _blend
			})
			with (spring) {
				hspd = _vel.x;
				vspd = _vel.y;
			}
			spent = true;
		} else return -1;
	}
}

function ToolGlide() : Tool("GLIDE") constructor {
	
	//Deploy small period with lift, then hover until down or jump is pressed
	icon = sTool_Glide;
	rope = noone;
	spent = false;
	
	static recall = function(_owner) {
		if (_owner.state = ePlayerState.GLIDE) {
			_owner.state = ePlayerState.FREE
		}
		
	}
	
	static shoot = function(_owner,_vel,_blend = c_white) {
		if (spent) {
			return -1;
		}
		
		var _self = self; // idk why, but self and other.self dont work down there
		_owner.glideLiftTimer = 0;
		_owner.state = ePlayerState.GLIDE;
		_owner.vspd = 0;
		spent = true;
	}
}
