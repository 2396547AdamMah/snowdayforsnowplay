function Vector2(_x=0,_y=0) constructor {
	x=_x;
	y=_y;
	
	static set = function(_nx,_ny) {
		x = _nx;
		y = _ny;
		return self;
	}
	static setPolar = function(_len,_dir) {
		x = lengthdir_x(_len,_dir);
		y = lengthdir_y(_len,_dir);
		return self;
	}
	
	static dir = function() {
		return point_direction(0,0,x,y);
	}
	static len = function() {
		return point_distance(0,0,x,y);
	}
	
	static normalized = function() {
		var _dist = sqrt(x*x + y*y);
		
		if (_dist != 0) {
			return new Vector2(x/_dist,y/_dist);	
		}
		else return new Vector2(0,0);
	}
	
	static multiply = function(_scalar) {
		return new Vector2(x*_scalar,y*_scalar);
	}
	
	return self;
}