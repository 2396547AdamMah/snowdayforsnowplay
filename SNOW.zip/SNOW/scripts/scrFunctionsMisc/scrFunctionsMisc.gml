function angleLerp(_angle1,_angle2,_amount,_tolerance = 1) {
	var ad = angle_difference(_angle2, _angle1);
	var _nAngle = _angle1;
	
	if (abs(ad) <= _tolerance) {
		_nAngle = _angle2;
	} else {
		_nAngle += ad*_amount;
	}
	
	return _nAngle;
}