function InputManager() constructor {
	kRight = false;
	kLeft = false;
	kUp = false;
	kUpPressed = false;
	kDown = false;
	kDownPressed = false;
	kDownReleased = false;
	kJumpPressed = false;
	kJumpHeld = false;
	kJumpReleased = false;
	kThrow = false;
	kRecall = false;
	kGrab = false;
	kSwitchTool = false;
	
	static update = function() {
		kRight = keyboard_check(vk_right)
		kLeft = keyboard_check(vk_left)
		kDown = keyboard_check(vk_down)
		kDownPressed = keyboard_check_pressed(vk_down)
		kDownReleased = keyboard_check_released(vk_down)
		kUp = keyboard_check(vk_up)
		kUpPressed = keyboard_check_pressed(vk_up)
		
		kJumpPressed = keyboard_check_pressed(ord("Z"))
		kJumpHeld = keyboard_check(ord("Z"))
		kJumpReleased = keyboard_check_released(ord("Z"))
		
		kGrab = keyboard_check(vk_up)
		
		kThrow = keyboard_check_pressed(ord("X"));
		kRecall = keyboard_check_pressed(ord("C"));
		kSwitchTool = keyboard_check_pressed(ord("S"))
	}
}